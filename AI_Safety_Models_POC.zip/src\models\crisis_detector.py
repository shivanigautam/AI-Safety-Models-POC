"""
Crisis Intervention Model
Recognizes severe emotional distress or self-harm indicators,
with potential triggers for human intervention.
"""

import re
import numpy as np
from typing import Dict, List, Tuple
from collections import defaultdict

class CrisisDetector:
    def __init__(self):
        self.crisis_threshold = 0.8
        self.high_risk_keywords = {
            'self_harm': [
                'kill myself', 'end it all', 'suicide', 'self harm', 'cut myself',
                'hurt myself', 'die', 'death', 'overdose', 'jump off'
            ],
            'despair': [
                'hopeless', 'worthless', 'nobody cares', 'no point', 'give up',
                'cant go on', 'tired of living', 'burden', 'alone forever'
            ],
            'emergency': [
                'right now', 'today', 'tonight', 'immediately', 'cant wait',
                'final decision', 'last time', 'goodbye', 'sorry everyone'
            ],
            'isolation': [
                'nobody understands', 'all alone', 'no friends', 'isolated',
                'no one cares', 'abandoned', 'rejected by everyone'
            ]
        }
        
        self.protective_factors = [
            'therapy', 'counselor', 'help', 'support', 'family', 'friends',
            'tomorrow', 'future', 'hope', 'better', 'treatment', 'medication'
        ]
        
        self.crisis_resources = {
            'hotlines': [
                "National Suicide Prevention Lifeline: 988",
                "Crisis Text Line: Text HOME to 741741",
                "International Association for Suicide Prevention: https://www.iasp.info/resources/Crisis_Centres/"
            ],
            'immediate_actions': [
                "If you're in immediate danger, please call emergency services (911)",
                "Reach out to a trusted friend, family member, or mental health professional",
                "Go to your nearest emergency room or crisis center"
            ]
        }
    
    def preprocess_text(self, text: str) -> str:
        """Clean and preprocess text for crisis analysis."""
        text = text.lower()
        # Preserve important phrases by not removing all punctuation
        text = re.sub(r'[^\w\s\'\-]', ' ', text)
        text = ' '.join(text.split())
        return text
    
    def detect_crisis_keywords(self, text: str) -> Dict[str, float]:
        """Detect crisis-related keywords and phrases."""
        processed_text = self.preprocess_text(text)
        
        scores = defaultdict(float)
        
        for category, keywords in self.high_risk_keywords.items():
            matches = 0
            total_severity = 0
            
            for keyword in keywords:
                if keyword in processed_text:
                    matches += 1
                    # Weight certain phrases more heavily
                    if category == 'self_harm' and keyword in ['kill myself', 'suicide', 'end it all']:
                        total_severity += 2
                    elif category == 'emergency' and keyword in ['right now', 'today', 'tonight']:
                        total_severity += 1.5
                    else:
                        total_severity += 1
            
            if matches > 0:
                scores[category] = min(total_severity / len(keywords), 1.0)
        
        return dict(scores)
    
    def analyze_linguistic_patterns(self, text: str) -> Dict[str, float]:
        """Analyze linguistic patterns associated with crisis states."""
        processed_text = self.preprocess_text(text)
        
        patterns = {
            'finality': 0.0,      # Final statements, goodbyes
            'hopelessness': 0.0,  # Expressions of no hope/future
            'pain': 0.0,          # Emotional or physical pain
            'isolation': 0.0,     # Feeling alone or disconnected
            'burden': 0.0         # Feeling like a burden to others
        }
        
        # Finality patterns
        finality_phrases = ['this is it', 'final', 'last time', 'goodbye', 'farewell', 'end of']
        for phrase in finality_phrases:
            if phrase in processed_text:
                patterns['finality'] += 0.3
        
        # Hopelessness patterns
        hopeless_phrases = ['no hope', 'no future', 'never get better', 'pointless', 'no way out']
        for phrase in hopeless_phrases:
            if phrase in processed_text:
                patterns['hopelessness'] += 0.4
        
        # Pain expressions
        pain_phrases = ['unbearable', 'cant take it', 'too much pain', 'suffering', 'agony']
        for phrase in pain_phrases:
            if phrase in processed_text:
                patterns['pain'] += 0.3
        
        # Isolation indicators
        isolation_phrases = ['nobody', 'alone', 'abandoned', 'rejected', 'no one']
        for phrase in isolation_phrases:
            if phrase in processed_text:
                patterns['isolation'] += 0.2
        
        # Burden indicators
        burden_phrases = ['burden', 'better off without me', 'waste of space', 'useless']
        for phrase in burden_phrases:
            if phrase in processed_text:
                patterns['burden'] += 0.4
        
        # Normalize scores
        for key in patterns:
            patterns[key] = min(patterns[key], 1.0)
        
        return patterns
    
    def detect_protective_factors(self, text: str) -> float:
        """Detect protective factors that might reduce crisis risk."""
        processed_text = self.preprocess_text(text)
        
        protective_score = 0.0
        for factor in self.protective_factors:
            if factor in processed_text:
                protective_score += 0.1
        
        # Look for future-oriented language
        future_phrases = ['tomorrow', 'next week', 'plans', 'looking forward', 'will try']
        for phrase in future_phrases:
            if phrase in processed_text:
                protective_score += 0.2
        
        return min(protective_score, 1.0)
    
    def assess_urgency_level(self, crisis_scores: Dict[str, float]) -> str:
        """Assess the urgency level based on crisis indicators."""
        max_score = max(crisis_scores.values()) if crisis_scores else 0.0
        
        # Check for immediate danger indicators
        if crisis_scores.get('self_harm', 0) > 0.7 or crisis_scores.get('emergency', 0) > 0.6:
            return 'IMMEDIATE'
        elif max_score > 0.6:
            return 'HIGH'
        elif max_score > 0.4:
            return 'MODERATE'
        elif max_score > 0.2:
            return 'LOW'
        else:
            return 'MINIMAL'
    
    def predict_crisis(self, text: str) -> Dict:
        """Predict crisis risk and provide intervention recommendations."""
        crisis_keywords = self.detect_crisis_keywords(text)
        linguistic_patterns = self.analyze_linguistic_patterns(text)
        protective_factors_score = self.detect_protective_factors(text)
        
        # Calculate overall crisis score
        crisis_score = 0.0
        
        # Weight crisis keywords heavily (50%)
        if crisis_keywords:
            max_keyword_score = max(crisis_keywords.values())
            crisis_score += max_keyword_score * 0.5
        
        # Weight linguistic patterns (30%)
        if linguistic_patterns:
            max_pattern_score = max(linguistic_patterns.values())
            crisis_score += max_pattern_score * 0.3
        
        # Adjust for protective factors (reduce score by up to 20%)
        crisis_score = max(0, crisis_score - (protective_factors_score * 0.2))
        
        # Determine urgency
        urgency_level = self.assess_urgency_level(crisis_keywords)
        
        # Override crisis detection for high-urgency cases
        if urgency_level in ['IMMEDIATE', 'HIGH']:
            crisis_score = max(crisis_score, 0.8)
        
        is_crisis = crisis_score > self.crisis_threshold
        
        result = {
            'is_crisis': is_crisis,
            'crisis_score': min(crisis_score, 1.0),
            'urgency_level': urgency_level,
            'crisis_keywords': crisis_keywords,
            'linguistic_patterns': linguistic_patterns,
            'protective_factors_score': protective_factors_score,
            'intervention_needed': urgency_level in ['IMMEDIATE', 'HIGH'],
            'resources': self.crisis_resources if is_crisis else {},
            'explanation': []
        }
        
        # Generate explanations
        if crisis_keywords:
            for category, score in crisis_keywords.items():
                if score > 0.3:
                    result['explanation'].append(f"Detected {category.replace('_', ' ')} indicators")
        
        if linguistic_patterns:
            for pattern, score in linguistic_patterns.items():
                if score > 0.4:
                    result['explanation'].append(f"Strong {pattern} expressions detected")
        
        if protective_factors_score > 0.3:
            result['explanation'].append("Some protective factors present")
        
        if urgency_level == 'IMMEDIATE':
            result['explanation'].append("IMMEDIATE INTERVENTION REQUIRED - Contact emergency services")
        elif urgency_level == 'HIGH':
            result['explanation'].append("High risk detected - Professional intervention recommended")
        
        return result
    
    def get_crisis_response_protocol(self, urgency_level: str) -> Dict[str, List[str]]:
        """Get appropriate response protocol based on urgency level."""
        protocols = {
            'IMMEDIATE': {
                'actions': [
                    "Contact emergency services immediately (911)",
                    "Do not leave the person alone",
                    "Remove any means of self-harm from immediate vicinity",
                    "Stay calm and listen without judgment",
                    "Get professional help immediately"
                ],
                'resources': self.crisis_resources['hotlines'] + self.crisis_resources['immediate_actions']
            },
            'HIGH': {
                'actions': [
                    "Encourage immediate professional help",
                    "Provide crisis hotline numbers",
                    "Suggest going to emergency room or crisis center",
                    "Connect with trusted friend or family member",
                    "Follow up within 24 hours"
                ],
                'resources': self.crisis_resources['hotlines']
            },
            'MODERATE': {
                'actions': [
                    "Provide mental health resources",
                    "Encourage talking to counselor or therapist",
                    "Check in regularly",
                    "Promote self-care activities",
                    "Monitor for escalation"
                ],
                'resources': ["National Suicide Prevention Lifeline: 988"]
            },
            'LOW': {
                'actions': [
                    "Provide general mental health resources",
                    "Encourage healthy coping strategies",
                    "Suggest professional support if needed"
                ],
                'resources': ["Mental health professionals in your area"]
            },
            'MINIMAL': {
                'actions': [
                    "Continue normal supportive conversation",
                    "Be aware of any changes in tone or content"
                ],
                'resources': []
            }
        }
        
        return protocols.get(urgency_level, protocols['MINIMAL'])
