"""
Abuse Language Detection Model
Detects harmful, threatening, or inappropriate content in user-generated text.
"""

import re
import numpy as np
from typing import Dict, List, Tuple
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
import joblib
import os

class AbuseDetector:
    def __init__(self):
        self.model = None
        self.confidence_threshold = 0.7
        self.abuse_keywords = {
            'profanity': ['damn', 'hell', 'stupid', 'idiot', 'moron'],
            'threats': ['kill', 'hurt', 'destroy', 'attack', 'harm'],
            'harassment': ['ugly', 'loser', 'worthless', 'pathetic', 'disgusting']
        }
        
    def preprocess_text(self, text: str) -> str:
        """Clean and preprocess text for analysis."""
        # Convert to lowercase
        text = text.lower()
        # Remove special characters but keep spaces
        text = re.sub(r'[^a-zA-Z0-9\s]', ' ', text)
        # Remove extra whitespace
        text = ' '.join(text.split())
        return text
    
    def keyword_detection(self, text: str) -> Dict[str, float]:
        """Rule-based keyword detection for quick filtering."""
        processed_text = self.preprocess_text(text)
        words = processed_text.split()
        
        scores = {
            'profanity': 0.0,
            'threats': 0.0,
            'harassment': 0.0
        }
        
        for category, keywords in self.abuse_keywords.items():
            matches = sum(1 for word in words if word in keywords)
            if matches > 0:
                scores[category] = min(matches / len(words) * 2, 1.0)
        
        return scores
    
    def train_model(self, training_data: List[Tuple[str, int]]):
        """Train the abuse detection model."""
        texts, labels = zip(*training_data)
        
        # Create pipeline with TF-IDF and Logistic Regression
        self.model = Pipeline([
            ('tfidf', TfidfVectorizer(max_features=10000, ngram_range=(1, 2))),
            ('classifier', LogisticRegression(random_state=42))
        ])
        
        # Preprocess texts
        processed_texts = [self.preprocess_text(text) for text in texts]
        
        # Train model
        self.model.fit(processed_texts, labels)
    
    def get_sample_training_data(self) -> List[Tuple[str, int]]:
        """Generate sample training data for demonstration."""
        sample_data = [
            # Non-abusive examples (label: 0)
            ("Hello, how are you today?", 0),
            ("I love this weather, it's so nice!", 0),
            ("Can you help me with this problem?", 0),
            ("Thank you for your assistance.", 0),
            ("Good morning everyone!", 0),
            ("I disagree with your opinion, but respect it.", 0),
            ("Let's work together on this project.", 0),
            ("I'm excited about the new features!", 0),
            
            # Abusive examples (label: 1)
            ("You are such an idiot, go away!", 1),
            ("I'm going to hurt you if you don't stop.", 1),
            ("You're worthless and ugly, nobody likes you.", 1),
            ("Shut up, you stupid moron!", 1),
            ("I hate you, you're disgusting!", 1),
            ("You're pathetic and should just disappear.", 1),
            ("Go kill yourself, loser!", 1),
            ("I'll destroy everything you care about!", 1),
        ]
        return sample_data
    
    def predict(self, text: str) -> Dict[str, float]:
        """Predict if text contains abuse and return confidence scores."""
        # Keyword-based detection
        keyword_scores = self.keyword_detection(text)
        
        result = {
            'is_abuse': False,
            'confidence': 0.0,
            'keyword_scores': keyword_scores,
            'ml_score': 0.0,
            'explanation': []
        }
        
        # Check keyword scores first
        max_keyword_score = max(keyword_scores.values())
        if max_keyword_score > 0.3:
            result['is_abuse'] = True
            result['confidence'] = max_keyword_score
            for category, score in keyword_scores.items():
                if score > 0.3:
                    result['explanation'].append(f"Contains {category} language")
        
        # ML model prediction (if trained)
        if self.model:
            try:
                processed_text = self.preprocess_text(text)
                ml_probability = self.model.predict_proba([processed_text])[0][1]
                result['ml_score'] = ml_probability
                
                if ml_probability > self.confidence_threshold:
                    result['is_abuse'] = True
                    result['confidence'] = max(result['confidence'], ml_probability)
                    result['explanation'].append("ML model detected abusive content")
            except Exception as e:
                print(f"ML prediction error: {e}")
        
        return result
    
    def save_model(self, filepath: str):
        """Save the trained model."""
        if self.model:
            joblib.dump(self.model, filepath)
    
    def load_model(self, filepath: str):
        """Load a pre-trained model."""
        if os.path.exists(filepath):
            self.model = joblib.load(filepath)
            return True
        return False
