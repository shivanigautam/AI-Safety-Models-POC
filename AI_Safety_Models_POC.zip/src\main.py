"""
Main Flask Application
AI Safety Models Web-based Chat Simulator
"""

import os
import sys
import time
import json
from datetime import datetime

# Add src to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__)))

# Try to import Flask, if not available, provide instructions
try:
    from flask import Flask, render_template, request, jsonify, session
    flask_available = True
except ImportError:
    flask_available = False
    print("Flask not available. Installing dependencies...")

# Import our safety models and utilities
try:
    from utils.safety_coordinator import SafetyCoordinator, SafetyLevel
    from utils.data_preprocessor import DataPreprocessor
    models_available = True
except ImportError:
    models_available = False
    print("Models not available. Installing dependencies...")

app = Flask(__name__)
app.secret_key = 'ai_safety_models_poc_secret_key_2024'

# Global safety coordinator
safety_coordinator = SafetyCoordinator()
preprocessor = DataPreprocessor()

# Initialize models on startup
@app.before_first_request
def initialize_app():
    """Initialize safety models when app starts."""
    print("Initializing AI Safety Models...")
    success = safety_coordinator.initialize_models()
    if success:
        print("✓ All safety models initialized successfully")
    else:
        print("✗ Some models failed to initialize")

@app.route('/')
def index():
    """Main chat interface."""
    return render_template('index.html')

@app.route('/api/analyze', methods=['POST'])
def analyze_message():
    """Analyze a message for safety concerns."""
    try:
        data = request.get_json()
        
        if not data or 'message' not in data:
            return jsonify({'error': 'No message provided'}), 400
        
        message = data.get('message', '').strip()
        user_age = data.get('user_age', 18)  # Default to adult
        guardian_settings = data.get('guardian_settings', {})
        
        if not message:
            return jsonify({'error': 'Empty message'}), 400
        
        # Perform safety assessment
        assessment = safety_coordinator.assess_content_safety(
            message, user_age, guardian_settings
        )
        
        # Format response
        response = {
            'message': message,
            'timestamp': datetime.now().isoformat(),
            'safety_assessment': {
                'level': assessment.safety_level.value,
                'score': round(assessment.overall_score, 3),
                'safe': assessment.safety_level in [SafetyLevel.SAFE, SafetyLevel.CAUTION],
                'requires_intervention': assessment.requires_intervention,
                'model_scores': {k: round(v, 3) for k, v in assessment.individual_scores.items()},
                'alerts': assessment.alerts,
                'recommendations': assessment.recommendations
            }
        }
        
        # Store in session for conversation tracking
        if 'conversation' not in session:
            session['conversation'] = []
        
        session['conversation'].append({
            'message': message,
            'assessment': response['safety_assessment'],
            'timestamp': response['timestamp']
        })
        
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500

@app.route('/api/conversation/history')
def get_conversation_history():
    """Get conversation history for current session."""
    try:
        conversation = session.get('conversation', [])
        return jsonify({
            'conversation': conversation,
            'total_messages': len(conversation)
        })
    except Exception as e:
        return jsonify({'error': f'Failed to retrieve history: {str(e)}'}), 500

@app.route('/api/conversation/reset', methods=['POST'])
def reset_conversation():
    """Reset conversation history and model state."""
    try:
        # Clear session conversation
        session.pop('conversation', None)
        
        # Reset safety coordinator
        safety_coordinator.reset_session()
        
        return jsonify({
            'success': True,
            'message': 'Conversation reset successfully'
        })
    except Exception as e:
        return jsonify({'error': f'Reset failed: {str(e)}'}), 500

@app.route('/api/safety/report')
def get_safety_report():
    """Get comprehensive safety report."""
    try:
        report = safety_coordinator.get_safety_report(include_history=True)
        return jsonify(report)
    except Exception as e:
        return jsonify({'error': f'Report generation failed: {str(e)}'}), 500

@app.route('/api/models/status')
def get_models_status():
    """Check status of all safety models."""
    try:
        status = {
            'abuse_detector': safety_coordinator.abuse_detector is not None,
            'escalation_detector': safety_coordinator.escalation_detector is not None,
            'crisis_detector': safety_coordinator.crisis_detector is not None,
            'content_filter': safety_coordinator.content_filter is not None,
            'all_initialized': all([
                safety_coordinator.abuse_detector,
                safety_coordinator.escalation_detector,
                safety_coordinator.crisis_detector,
                safety_coordinator.content_filter
            ])
        }
        return jsonify(status)
    except Exception as e:
        return jsonify({'error': f'Status check failed: {str(e)}'}), 500

@app.route('/api/demo/messages')
def get_demo_messages():
    """Get sample messages for testing different safety scenarios."""
    demo_messages = {
        'safe': [
            "Hello, how are you today?",
            "I love learning new things!",
            "The weather is really nice.",
            "Thank you for your help.",
            "I'm excited about this project."
        ],
        'abuse': [
            "You're such an idiot!",
            "I hate you so much.",
            "Go away, nobody likes you.",
            "You're worthless and stupid."
        ],
        'escalation': [
            "I'm getting really frustrated with this.",
            "Why don't you ever listen to me?",
            "This is the third time I've told you!",
            "I'm getting really angry now."
        ],
        'crisis': [
            "I feel so hopeless right now.",
            "Nobody would miss me if I was gone.",
            "I can't take this pain anymore.",
            "I just want it all to end."
        ],
        'content_inappropriate_child': [
            "Let's talk about adult topics.",
            "This movie has violence and scary scenes.",
            "Have you tried alcohol before?",
            "This content is for mature audiences."
        ]
    }
    
    return jsonify(demo_messages)

@app.route('/dashboard')
def dashboard():
    """Safety monitoring dashboard."""
    return render_template('dashboard.html')

@app.route('/realtime')
def realtime_test():
    """Real-time testing interface."""
    return render_template('realtime_test.html')

@app.route('/api/export/data', methods=['POST'])
def export_assessment_data():
    """Export assessment data for analysis."""
    try:
        # Create exports directory if it doesn't exist
        exports_dir = os.path.join(os.path.dirname(__file__), '..', 'data', 'exports')
        os.makedirs(exports_dir, exist_ok=True)
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'safety_assessment_export_{timestamp}.json'
        filepath = os.path.join(exports_dir, filename)
        
        # Export data
        success = safety_coordinator.export_assessment_data(filepath)
        
        if success:
            return jsonify({
                'success': True,
                'filename': filename,
                'filepath': filepath
            })
        else:
            return jsonify({'error': 'Export failed'}), 500
            
    except Exception as e:
        return jsonify({'error': f'Export failed: {str(e)}'}), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    print("=" * 60)
    print("AI Safety Models POC - Web Application")
    print("=" * 60)
    print("Initializing safety models...")
    
    # Create necessary directories
    os.makedirs('models', exist_ok=True)
    os.makedirs('data/exports', exist_ok=True)
    
    print("Starting Flask application...")
    print("Access the application at: http://localhost:5000")
    print("Dashboard available at: http://localhost:5000/dashboard") 
    print("Real-time Testing at: http://localhost:5000/realtime")
    print("=" * 60)
    
    # Run Flask app
    app.run(
        debug=True,
        host='0.0.0.0',
        port=5000,
        threaded=True
    )
