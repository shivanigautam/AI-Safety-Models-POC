"""
Simple Command Line Interface for AI Safety Models
This version works without Flask for basic testing and demonstration.
"""

import os
import sys
import time
from typing import Dict, List

# Add src to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__)))

# Import safety models with fallback
try:
    from utils.safety_coordinator import SafetyCoordinator, SafetyLevel
    from models.abuse_detector import AbuseDetector
    from models.escalation_detector import EscalationDetector
    from models.crisis_detector import CrisisDetector
    from models.content_filter import ContentFilter
    models_available = True
except ImportError as e:
    print(f"Some models not available: {e}")
    models_available = False

def print_banner():
    """Print application banner."""
    print("=" * 60)
    print("🛡️  AI Safety Models - Command Line Interface")
    print("=" * 60)
    print("Real-time Safety Analysis for Conversational AI")
    print()

def print_safety_assessment(message: str, assessment: Dict):
    """Print formatted safety assessment."""
    print(f"📝 Message: \"{message}\"")
    print(f"🛡️  Safety Assessment:")
    
    if hasattr(assessment, 'safety_level'):
        # SafetyAssessment object
        level = assessment.safety_level.value
        score = assessment.overall_score
        alerts = assessment.alerts
        recommendations = assessment.recommendations
        requires_intervention = assessment.requires_intervention
    else:
        # Dictionary format
        level = assessment.get('safety_level', 'unknown')
        score = assessment.get('overall_score', 0.0)
        alerts = assessment.get('alerts', [])
        recommendations = assessment.get('recommendations', [])
        requires_intervention = assessment.get('requires_intervention', False)
    
    # Safety level with color coding (text-based)
    level_symbols = {
        'safe': '🟢',
        'caution': '🟡', 
        'warning': '🟠',
        'danger': '🔴',
        'critical': '🚨'
    }
    
    symbol = level_symbols.get(level.lower(), '❓')
    print(f"   Level: {symbol} {level.upper()}")
    print(f"   Risk Score: {score:.1%}")
    
    if requires_intervention:
        print("   🚨 INTERVENTION REQUIRED!")
    
    if alerts:
        print("   Alerts:")
        for alert in alerts:
            print(f"     ⚠️  {alert}")
    
    if recommendations:
        print("   Recommendations:")
        for rec in recommendations:
            print(f"     💡 {rec}")
    
    print()

def simple_safety_check(message: str, user_age: int = 18) -> Dict:
    """Simple safety check without full model integration."""
    
    # Basic keyword-based safety check
    abuse_keywords = ['idiot', 'hate', 'stupid', 'kill', 'die', 'worthless']
    crisis_keywords = ['suicide', 'kill myself', 'end it all', 'hopeless', 'no point']
    
    abuse_detected = any(keyword in message.lower() for keyword in abuse_keywords)
    crisis_detected = any(keyword in message.lower() for keyword in crisis_keywords)
    
    # Determine safety level
    if crisis_detected:
        level = 'critical'
        score = 0.9
        alerts = ['Crisis language detected']
        recommendations = ['Immediate professional help recommended', 'Contact crisis hotline: 988']
        intervention = True
    elif abuse_detected:
        level = 'warning'
        score = 0.7
        alerts = ['Abusive language detected']
        recommendations = ['Please use respectful language']
        intervention = False
    else:
        level = 'safe'
        score = 0.1
        alerts = []
        recommendations = []
        intervention = False
    
    return {
        'safety_level': level,
        'overall_score': score,
        'alerts': alerts,
        'recommendations': recommendations,
        'requires_intervention': intervention
    }

def run_interactive_mode():
    """Run interactive chat mode."""
    print("🗣️  Interactive Chat Mode")
    print("Type messages to analyze their safety. Type 'quit' to exit.")
    print("Available commands: 'demo', 'age <number>', 'help', 'quit'")
    print("-" * 40)
    
    user_age = 18
    message_count = 0
    
    # Try to initialize full system
    coordinator = None
    if models_available:
        try:
            coordinator = SafetyCoordinator()
            success = coordinator.initialize_models()
            if success:
                print("✅ Full AI Safety Models loaded successfully!")
            else:
                print("⚠️  Using simplified safety analysis (some dependencies missing)")
                coordinator = None
        except Exception as e:
            print(f"⚠️  Using simplified safety analysis: {e}")
            coordinator = None
    else:
        print("⚠️  Using simplified safety analysis (dependencies not installed)")
    
    print()
    
    while True:
        try:
            user_input = input("💬 Enter message: ").strip()
            
            if user_input.lower() in ['quit', 'exit', 'q']:
                break
            elif user_input.lower() == 'help':
                print("Commands:")
                print("  demo - Show demo messages")
                print("  age <number> - Set user age for content filtering")
                print("  help - Show this help")
                print("  quit - Exit the program")
                continue
            elif user_input.lower().startswith('age '):
                try:
                    new_age = int(user_input.split()[1])
                    user_age = new_age
                    print(f"✅ User age set to {user_age}")
                except (ValueError, IndexError):
                    print("❌ Invalid age. Use: age <number>")
                continue
            elif user_input.lower() == 'demo':
                demo_messages = [
                    "Hello, how are you today?",
                    "You're such an idiot, I hate you!",
                    "I feel so hopeless, I want to end it all.",
                    "This movie has violent scenes with blood."
                ]
                print("🎭 Demo Messages:")
                for i, msg in enumerate(demo_messages, 1):
                    print(f"{i}. {msg}")
                continue
            elif not user_input:
                continue
            
            message_count += 1
            print(f"\n--- Analysis #{message_count} ---")
            
            # Perform safety analysis
            start_time = time.time()
            
            if coordinator:
                try:
                    assessment = coordinator.assess_content_safety(user_input, user_age)
                    end_time = time.time()
                    print_safety_assessment(user_input, assessment)
                    print(f"⏱️  Analysis time: {(end_time - start_time)*1000:.1f}ms")
                except Exception as e:
                    print(f"❌ Analysis error: {e}")
                    assessment = simple_safety_check(user_input, user_age)
                    print_safety_assessment(user_input, assessment)
            else:
                assessment = simple_safety_check(user_input, user_age)
                end_time = time.time()
                print_safety_assessment(user_input, assessment)
                print(f"⏱️  Analysis time: {(end_time - start_time)*1000:.1f}ms")
            
        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"❌ Error: {e}")

def run_batch_demo():
    """Run batch demonstration with predefined messages."""
    print("🎭 Batch Demo Mode")
    print("Testing various safety scenarios...")
    print("-" * 40)
    
    demo_scenarios = [
        ("Safe conversation", "Hello, how are you today? I hope you're having a great day!"),
        ("Mild frustration", "This is getting a bit frustrating, but I understand."),
        ("Abusive language", "You're such an idiot! I hate dealing with you!"),
        ("Crisis situation", "I feel so hopeless. Nobody would miss me if I was gone."),
        ("Age-inappropriate (child)", "Let's talk about violent movies with lots of blood."),
    ]
    
    # Try to initialize system
    coordinator = None
    if models_available:
        try:
            coordinator = SafetyCoordinator()
            success = coordinator.initialize_models()
            if not success:
                coordinator = None
        except:
            coordinator = None
    
    for i, (scenario, message) in enumerate(demo_scenarios, 1):
        print(f"\n🎯 Scenario {i}: {scenario}")
        
        if coordinator:
            try:
                assessment = coordinator.assess_content_safety(message, user_age=18)
                print_safety_assessment(message, assessment)
            except Exception as e:
                print(f"❌ Analysis error: {e}")
                assessment = simple_safety_check(message)
                print_safety_assessment(message, assessment)
        else:
            assessment = simple_safety_check(message)
            print_safety_assessment(message, assessment)

def main():
    """Main application entry point."""
    print_banner()
    
    # Check system status
    if not models_available:
        print("⚠️  WARNING: Some AI safety models are not available.")
        print("   This could be due to missing dependencies.")
        print("   The application will use simplified safety analysis.")
        print()
        print("💡 To install full dependencies, run:")
        print("   pip install flask scikit-learn pandas numpy nltk textblob")
        print()
    
    # Show menu
    print("Choose an option:")
    print("1. Interactive chat mode")
    print("2. Batch demo mode")
    print("3. Exit")
    
    while True:
        try:
            choice = input("\nEnter your choice (1-3): ").strip()
            
            if choice == '1':
                run_interactive_mode()
                break
            elif choice == '2':
                run_batch_demo()
                break
            elif choice == '3':
                print("👋 Goodbye!")
                break
            else:
                print("❌ Invalid choice. Please enter 1, 2, or 3.")
        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
            break

if __name__ == "__main__":
    main()