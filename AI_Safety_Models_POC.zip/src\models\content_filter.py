"""
Content Filtering Model
Age-appropriate content filtering for guardian-supervised accounts,
ensuring content is suitable based on user age profiles.
"""

import re
import json
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

class AgeGroup(Enum):
    CHILD = "0-12"      # Children
    TEEN = "13-17"      # Teenagers
    ADULT = "18+"       # Adults

@dataclass
class ContentPolicy:
    age_group: AgeGroup
    allowed_topics: List[str]
    restricted_topics: List[str]
    blocked_keywords: List[str]
    max_violence_level: int  # 0-5 scale
    max_mature_content_level: int  # 0-5 scale

class ContentFilter:
    def __init__(self):
        self.policies = self._initialize_age_policies()
        self.violence_keywords = {
            1: ['fight', 'hit', 'push'],
            2: ['punch', 'kick', 'slap', 'attack'],
            3: ['blood', 'injury', 'wound', 'hurt badly'],
            4: ['weapon', 'gun', 'knife', 'kill', 'murder'],
            5: ['torture', 'dismember', 'gore', 'brutal death']
        }
        
        self.mature_content_keywords = {
            1: ['romance', 'dating', 'crush', 'like someone'],
            2: ['kiss', 'boyfriend', 'girlfriend', 'love'],
            3: ['intimate', 'sexual', 'adult content', 'mature'],
            4: ['explicit', 'graphic', 'sexual content'],
            5: ['pornographic', 'x-rated', 'hardcore']
        }
        
        self.educational_topics = [
            'science', 'math', 'history', 'geography', 'literature',
            'art', 'music', 'sports', 'nature', 'animals', 'space',
            'technology', 'coding', 'programming', 'learning'
        ]
        
        self.always_blocked = [
            'illegal drugs', 'alcohol abuse', 'gambling', 'self harm',
            'suicide', 'hate speech', 'discrimination', 'bullying',
            'cyberbullying', 'personal information', 'address', 'phone number'
        ]
    
    def _initialize_age_policies(self) -> Dict[AgeGroup, ContentPolicy]:
        """Initialize content policies for different age groups."""
        return {
            AgeGroup.CHILD: ContentPolicy(
                age_group=AgeGroup.CHILD,
                allowed_topics=[
                    'education', 'games', 'cartoons', 'animals', 'nature',
                    'family', 'friends', 'school', 'hobbies', 'sports'
                ],
                restricted_topics=[
                    'violence', 'scary content', 'mature themes', 'romance',
                    'politics', 'religion', 'money', 'news'
                ],
                blocked_keywords=[
                    'death', 'kill', 'murder', 'blood', 'weapon', 'gun',
                    'scary', 'monster', 'ghost', 'nightmare', 'sexual',
                    'adult', 'mature', 'inappropriate'
                ],
                max_violence_level=1,
                max_mature_content_level=0
            ),
            
            AgeGroup.TEEN: ContentPolicy(
                age_group=AgeGroup.TEEN,
                allowed_topics=[
                    'education', 'social issues', 'relationships', 'career',
                    'technology', 'entertainment', 'sports', 'music',
                    'movies', 'books', 'current events'
                ],
                restricted_topics=[
                    'extreme violence', 'explicit content', 'illegal activities',
                    'adult themes', 'graphic content'
                ],
                blocked_keywords=[
                    'explicit sexual', 'pornographic', 'illegal drugs',
                    'extreme violence', 'torture', 'graphic death',
                    'hate speech', 'discrimination'
                ],
                max_violence_level=3,
                max_mature_content_level=2
            ),
            
            AgeGroup.ADULT: ContentPolicy(
                age_group=AgeGroup.ADULT,
                allowed_topics=['all'],  # Adults can discuss most topics
                restricted_topics=[
                    'illegal activities', 'harmful content', 'hate speech'
                ],
                blocked_keywords=[
                    'illegal activities', 'how to harm', 'hate speech',
                    'discrimination', 'harassment'
                ],
                max_violence_level=5,
                max_mature_content_level=5
            )
        }
    
    def preprocess_text(self, text: str) -> str:
        """Clean and preprocess text for content analysis."""
        text = text.lower()
        text = re.sub(r'[^\w\s]', ' ', text)
        text = ' '.join(text.split())
        return text
    
    def detect_violence_level(self, text: str) -> Tuple[int, List[str]]:
        """Detect violence level in text (0-5 scale)."""
        processed_text = self.preprocess_text(text)
        max_level = 0
        detected_keywords = []
        
        for level, keywords in self.violence_keywords.items():
            for keyword in keywords:
                if keyword in processed_text:
                    max_level = max(max_level, level)
                    detected_keywords.append(keyword)
        
        return max_level, detected_keywords
    
    def detect_mature_content_level(self, text: str) -> Tuple[int, List[str]]:
        """Detect mature content level in text (0-5 scale)."""
        processed_text = self.preprocess_text(text)
        max_level = 0
        detected_keywords = []
        
        for level, keywords in self.mature_content_keywords.items():
            for keyword in keywords:
                if keyword in processed_text:
                    max_level = max(max_level, level)
                    detected_keywords.append(keyword)
        
        return max_level, detected_keywords
    
    def check_blocked_keywords(self, text: str, age_group: AgeGroup) -> Tuple[bool, List[str]]:
        """Check for blocked keywords based on age group."""
        processed_text = self.preprocess_text(text)
        policy = self.policies[age_group]
        
        blocked_found = []
        
        # Check age-specific blocked keywords
        for keyword in policy.blocked_keywords:
            if keyword in processed_text:
                blocked_found.append(keyword)
        
        # Check always blocked content
        for keyword in self.always_blocked:
            if keyword in processed_text:
                blocked_found.append(keyword)
        
        return len(blocked_found) > 0, blocked_found
    
    def check_educational_content(self, text: str) -> Tuple[bool, List[str]]:
        """Check if content is educational."""
        processed_text = self.preprocess_text(text)
        educational_found = []
        
        for topic in self.educational_topics:
            if topic in processed_text:
                educational_found.append(topic)
        
        return len(educational_found) > 0, educational_found
    
    def analyze_topic_appropriateness(self, text: str, age_group: AgeGroup) -> Dict[str, float]:
        """Analyze if topics in text are appropriate for age group."""
        processed_text = self.preprocess_text(text)
        policy = self.policies[age_group]
        
        scores = {
            'appropriate_topics': 0.0,
            'restricted_topics': 0.0,
            'educational_bonus': 0.0
        }
        
        # Check for allowed topics
        if 'all' not in policy.allowed_topics:
            topic_matches = 0
            for topic in policy.allowed_topics:
                if topic in processed_text:
                    topic_matches += 1
            
            if topic_matches > 0:
                scores['appropriate_topics'] = min(topic_matches / len(policy.allowed_topics), 1.0)
        else:
            scores['appropriate_topics'] = 1.0  # Adults can discuss all topics
        
        # Check for restricted topics
        restricted_matches = 0
        for topic in policy.restricted_topics:
            if topic in processed_text:
                restricted_matches += 1
        
        if restricted_matches > 0:
            scores['restricted_topics'] = min(restricted_matches / len(policy.restricted_topics), 1.0)
        
        # Educational content bonus
        is_educational, _ = self.check_educational_content(text)
        if is_educational:
            scores['educational_bonus'] = 0.2
        
        return scores
    
    def filter_content(self, text: str, user_age: int, guardian_settings: Optional[Dict] = None) -> Dict:
        """Filter content based on user age and guardian settings."""
        # Determine age group
        if user_age <= 12:
            age_group = AgeGroup.CHILD
        elif user_age <= 17:
            age_group = AgeGroup.TEEN
        else:
            age_group = AgeGroup.ADULT
        
        # Apply guardian overrides if provided
        if guardian_settings:
            if 'stricter_filtering' in guardian_settings and guardian_settings['stricter_filtering']:
                if age_group == AgeGroup.TEEN:
                    age_group = AgeGroup.CHILD
        
        policy = self.policies[age_group]
        
        # Analyze content
        violence_level, violence_keywords = self.detect_violence_level(text)
        mature_level, mature_keywords = self.detect_mature_content_level(text)
        has_blocked, blocked_keywords = self.check_blocked_keywords(text, age_group)
        is_educational, educational_topics = self.check_educational_content(text)
        topic_scores = self.analyze_topic_appropriateness(text, age_group)
        
        # Determine if content should be blocked
        should_block = False
        block_reasons = []
        
        # Check violence level
        if violence_level > policy.max_violence_level:
            should_block = True
            block_reasons.append(f"Violence level {violence_level} exceeds limit {policy.max_violence_level}")
        
        # Check mature content level
        if mature_level > policy.max_mature_content_level:
            should_block = True
            block_reasons.append(f"Mature content level {mature_level} exceeds limit {policy.max_mature_content_level}")
        
        # Check blocked keywords
        if has_blocked:
            should_block = True
            block_reasons.append(f"Contains blocked keywords: {', '.join(blocked_keywords)}")
        
        # Check restricted topics
        if topic_scores['restricted_topics'] > 0.5:
            should_block = True
            block_reasons.append("Contains restricted topics for this age group")
        
        # Calculate overall appropriateness score
        appropriateness_score = 0.0
        if not should_block:
            appropriateness_score = topic_scores['appropriate_topics']
            if is_educational:
                appropriateness_score = min(1.0, appropriateness_score + topic_scores['educational_bonus'])
        
        result = {
            'is_appropriate': not should_block,
            'age_group': age_group.value,
            'appropriateness_score': appropriateness_score,
            'violence_level': violence_level,
            'mature_content_level': mature_level,
            'is_educational': is_educational,
            'block_reasons': block_reasons,
            'detected_keywords': {
                'violence': violence_keywords,
                'mature_content': mature_keywords,
                'blocked': blocked_keywords,
                'educational': educational_topics
            },
            'topic_analysis': topic_scores,
            'recommendations': []
        }
        
        # Generate recommendations
        if should_block:
            result['recommendations'].append("Content blocked due to age restrictions")
            if violence_level > policy.max_violence_level:
                result['recommendations'].append("Consider discussing conflict resolution instead")
            if mature_level > policy.max_mature_content_level:
                result['recommendations'].append("Age-appropriate relationship education resources available")
        elif is_educational:
            result['recommendations'].append("Great educational content!")
        
        return result
    
    def get_age_appropriate_alternatives(self, blocked_content_type: str, age_group: AgeGroup) -> List[str]:
        """Suggest age-appropriate alternatives for blocked content."""
        alternatives = {
            'violence': {
                AgeGroup.CHILD: [
                    "Let's talk about solving problems peacefully",
                    "How about discussing your favorite games or activities?",
                    "Would you like to learn about animals or nature?"
                ],
                AgeGroup.TEEN: [
                    "Let's discuss conflict resolution strategies",
                    "How about exploring sports or competitive activities?",
                    "Would you like to talk about current events or social issues?"
                ]
            },
            'mature_content': {
                AgeGroup.CHILD: [
                    "Let's talk about friendship and family",
                    "How about discussing school or hobbies?",
                    "Would you like to explore science or art topics?"
                ],
                AgeGroup.TEEN: [
                    "Let's discuss healthy relationships",
                    "How about exploring career interests?",
                    "Would you like to talk about personal development?"
                ]
            }
        }
        
        return alternatives.get(blocked_content_type, {}).get(age_group, [
            "Let's explore a different topic that might interest you!"
        ])
