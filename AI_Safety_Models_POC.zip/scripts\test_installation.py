"""
Test script to verify the AI Safety Models installation and basic functionality.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

def test_imports():
    """Test if all required modules can be imported."""
    print("Testing imports...")
    
    try:
        # Test core libraries
        import flask
        import sklearn
        import pandas
        import numpy
        print("✓ Core libraries imported successfully")
        
        # Test our models
        from models.abuse_detector import AbuseDetector
        from models.escalation_detector import EscalationDetector  
        from models.crisis_detector import CrisisDetector
        from models.content_filter import ContentFilter
        print("✓ All safety models imported successfully")
        
        # Test utilities
        from utils.data_preprocessor import DataPreprocessor
        from utils.safety_coordinator import SafetyCoordinator
        print("✓ Utility modules imported successfully")
        
        return True
        
    except ImportError as e:
        print(f"✗ Import error: {e}")
        return False

def test_model_initialization():
    """Test if models can be initialized properly."""
    print("\nTesting model initialization...")
    
    try:
        from models.abuse_detector import AbuseDetector
        from models.escalation_detector import EscalationDetector  
        from models.crisis_detector import CrisisDetector
        from models.content_filter import ContentFilter
        from utils.safety_coordinator import SafetyCoordinator
        
        # Initialize individual models
        abuse_detector = AbuseDetector()
        escalation_detector = EscalationDetector()
        crisis_detector = CrisisDetector()
        content_filter = ContentFilter()
        print("✓ Individual models initialized")
        
        # Initialize coordinator
        coordinator = SafetyCoordinator()
        success = coordinator.initialize_models()
        
        if success:
            print("✓ Safety coordinator initialized successfully")
            return True
        else:
            print("✗ Safety coordinator initialization failed")
            return False
            
    except Exception as e:
        print(f"✗ Initialization error: {e}")
        return False

def test_basic_functionality():
    """Test basic functionality of the safety models."""
    print("\nTesting basic functionality...")
    
    try:
        from utils.safety_coordinator import SafetyCoordinator
        
        coordinator = SafetyCoordinator()
        coordinator.initialize_models()
        
        # Test safe message
        test_message = "Hello, how are you today?"
        assessment = coordinator.assess_content_safety(test_message, user_age=18)
        
        print(f"✓ Test message analyzed: '{test_message}'")
        print(f"  Safety level: {assessment.safety_level.value}")
        print(f"  Overall score: {assessment.overall_score:.3f}")
        
        return True
        
    except Exception as e:
        print(f"✗ Functionality test error: {e}")
        return False

def test_flask_app():
    """Test if Flask app can be created."""
    print("\nTesting Flask application setup...")
    
    try:
        import sys
        import os
        
        # Add src to path temporarily
        src_path = os.path.join(os.path.dirname(__file__), '..', 'src')
        if src_path not in sys.path:
            sys.path.insert(0, src_path)
        
        # Import and create app
        from main import app
        
        print("✓ Flask application created successfully")
        print("  You can now run 'python src/main.py' to start the web interface")
        
        return True
        
    except Exception as e:
        print(f"✗ Flask app test error: {e}")
        return False

def main():
    """Run all tests."""
    print("="*60)
    print("AI SAFETY MODELS - INSTALLATION VERIFICATION")
    print("="*60)
    
    tests = [
        ("Import Test", test_imports),
        ("Model Initialization Test", test_model_initialization), 
        ("Basic Functionality Test", test_basic_functionality),
        ("Flask App Test", test_flask_app)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\n🔍 Running {test_name}...")
        result = test_func()
        results.append((test_name, result))
        
        if result:
            print(f"✅ {test_name} PASSED")
        else:
            print(f"❌ {test_name} FAILED")
    
    # Summary
    print(f"\n{'='*60}")
    print("TEST SUMMARY")
    print(f"{'='*60}")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {test_name}")
    
    print(f"\n📊 Overall: {passed}/{total} tests passed")
    
    if passed == total:
        print(f"\n🎉 ALL TESTS PASSED!")
        print(f"The AI Safety Models system is ready to use.")
        print(f"\nNext steps:")
        print(f"1. Run the web application: python src/main.py")
        print(f"2. Open http://localhost:5000 in your browser")
        print(f"3. Try the demo: python scripts/demo.py")
        print(f"4. Run evaluation: python scripts/evaluate_models.py")
    else:
        print(f"\n⚠️ SOME TESTS FAILED")
        print(f"Please check the error messages above and ensure all dependencies are installed.")
        
    return passed == total

if __name__ == "__main__":
    main()