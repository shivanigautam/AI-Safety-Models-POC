"""
Simplified Demo for AI Safety Models
Works without external dependencies to demonstrate core concepts.
"""

import os
import sys
import time

def print_banner():
    """Print application banner."""
    print("=" * 60)
    print("🛡️  AI Safety Models POC - DEMONSTRATION")
    print("=" * 60)
    print("Real-time Safety Analysis for Conversational AI")
    print("Note: Running in simplified mode for demonstration")
    print()

def simple_safety_analysis(message: str, user_age: int = 18) -> dict:
    """Simplified safety analysis without external dependencies."""
    
    # Abuse Detection - keyword based
    abuse_keywords = ['idiot', 'hate', 'stupid', 'kill', 'die', 'worthless', 'moron', 'loser']
    abuse_detected = any(keyword in message.lower() for keyword in abuse_keywords)
    abuse_score = 0.8 if abuse_detected else 0.1
    
    # Crisis Detection - keyword based  
    crisis_keywords = ['suicide', 'kill myself', 'end it all', 'hopeless', 'no point', 'want to die']
    crisis_detected = any(keyword in message.lower() for keyword in crisis_keywords)
    crisis_score = 0.9 if crisis_detected else 0.1
    
    # Escalation Detection - simple pattern matching
    escalation_keywords = ['frustrated', 'angry', 'furious', 'mad', 'annoying', 'terrible']
    escalation_detected = any(keyword in message.lower() for keyword in escalation_keywords)
    escalation_score = 0.6 if escalation_detected else 0.1
    
    # Content Filtering - age-based
    inappropriate_child = ['violence', 'blood', 'weapon', 'adult', 'mature', 'scary']
    content_inappropriate = user_age < 13 and any(word in message.lower() for word in inappropriate_child)
    content_score = 0.7 if content_inappropriate else 0.1
    
    # Overall assessment
    max_score = max(abuse_score, crisis_score, escalation_score, content_score)
    
    if crisis_score > 0.8:
        level = 'CRITICAL'
        intervention = True
    elif max_score > 0.7:
        level = 'DANGER'
        intervention = False
    elif max_score > 0.5:
        level = 'WARNING'
        intervention = False
    elif max_score > 0.3:
        level = 'CAUTION'
        intervention = False
    else:
        level = 'SAFE'
        intervention = False
    
    alerts = []
    recommendations = []
    
    if abuse_detected:
        alerts.append('Abusive language detected')
        recommendations.append('Please use respectful language')
    
    if crisis_detected:
        alerts.append('Crisis language detected')
        recommendations.append('Crisis resources: Call 988 (Suicide Prevention Lifeline)')
        intervention = True
    
    if escalation_detected:
        alerts.append('Escalation patterns detected')
        recommendations.append('Consider taking a break to cool down')
    
    if content_inappropriate:
        alerts.append('Content inappropriate for user age')
        recommendations.append('Age-appropriate alternatives available')
    
    return {
        'safety_level': level,
        'overall_score': max_score,
        'individual_scores': {
            'abuse': abuse_score,
            'crisis': crisis_score,
            'escalation': escalation_score,
            'content': content_score
        },
        'alerts': alerts,
        'recommendations': recommendations,
        'requires_intervention': intervention
    }

def print_assessment(message: str, assessment: dict):
    """Print formatted safety assessment."""
    level_colors = {
        'SAFE': '🟢',
        'CAUTION': '🟡',
        'WARNING': '🟠', 
        'DANGER': '🔴',
        'CRITICAL': '🚨'
    }
    
    symbol = level_colors.get(assessment['safety_level'], '❓')
    
    print(f"📝 Message: \"{message}\"")
    print(f"🛡️  Safety Assessment:")
    print(f"   Level: {symbol} {assessment['safety_level']}")
    print(f"   Overall Risk: {assessment['overall_score']:.1%}")
    
    if assessment['requires_intervention']:
        print("   🚨 INTERVENTION REQUIRED!")
    
    print(f"   Model Scores:")
    for model, score in assessment['individual_scores'].items():
        print(f"     {model.title()}: {score:.1%}")
    
    if assessment['alerts']:
        print("   Alerts:")
        for alert in assessment['alerts']:
            print(f"     ⚠️  {alert}")
    
    if assessment['recommendations']:
        print("   Recommendations:")
        for rec in assessment['recommendations']:
            print(f"     💡 {rec}")
    
    print()

def demo_individual_scenarios():
    """Demonstrate individual safety scenarios."""
    print("🎯 SAFETY SCENARIO DEMONSTRATIONS")
    print("=" * 50)
    
    scenarios = [
        {
            'name': 'Safe Conversation',
            'message': 'Hello! How are you doing today? I hope you\'re having a great day!',
            'user_age': 18,
            'description': 'Normal, friendly conversation'
        },
        {
            'name': 'Abusive Language',
            'message': 'You\'re such an idiot! I hate dealing with you, you worthless moron!',
            'user_age': 18,
            'description': 'Contains multiple abusive terms'
        },
        {
            'name': 'Escalation Pattern',
            'message': 'This is getting really frustrating! I\'m getting angry with this terrible system!',
            'user_age': 18,
            'description': 'Shows frustration and anger escalation'
        },
        {
            'name': 'Crisis Situation',
            'message': 'I feel so hopeless. There\'s no point in continuing. I want to end it all.',
            'user_age': 20,
            'description': 'Critical mental health crisis requiring intervention'
        },
        {
            'name': 'Age-Inappropriate Content (Child)',
            'message': 'Let\'s watch a movie with lots of violence, blood, and scary adult content.',
            'user_age': 8,
            'description': 'Content inappropriate for child user'
        },
        {
            'name': 'Same Content (Teen)',
            'message': 'Let\'s watch a movie with lots of violence, blood, and scary adult content.',
            'user_age': 16,
            'description': 'Same content but for teen user'
        }
    ]
    
    for i, scenario in enumerate(scenarios, 1):
        print(f"Scenario {i}: {scenario['name']}")
        print(f"Description: {scenario['description']}")
        print(f"User Age: {scenario['user_age']}")
        print("-" * 30)
        
        start_time = time.time()
        assessment = simple_safety_analysis(scenario['message'], scenario['user_age'])
        end_time = time.time()
        
        print_assessment(scenario['message'], assessment)
        print(f"⏱️  Analysis Time: {(end_time - start_time)*1000:.1f}ms")
        print()

def demo_conversation_flow():
    """Demonstrate escalating conversation."""
    print("🗣️  CONVERSATION FLOW DEMONSTRATION")
    print("=" * 50)
    print("Simulating a conversation that escalates over time...")
    print()
    
    conversation = [
        ("Hi, I need help with my account.", "Initial contact - polite request"),
        ("The system keeps giving me errors when I try to login.", "Reporting problem calmly"),
        ("This is getting frustrating. I've tried multiple times.", "Starting to show frustration"),
        ("I'm really getting angry now! This is terrible service!", "Clear escalation with anger"),
        ("You people are completely useless! I hate this stupid system!", "High escalation with abuse"),
        ("I'm so frustrated I could scream! Fix this now or I'll complain everywhere!", "Peak escalation")
    ]
    
    for i, (message, context) in enumerate(conversation, 1):
        print(f"💬 Message {i}: {context}")
        
        assessment = simple_safety_analysis(message)
        
        # Show progression
        if assessment['safety_level'] == 'SAFE':
            progression = "📈 Baseline - Normal conversation"
        elif assessment['safety_level'] == 'CAUTION':
            progression = "📈 Slight concern detected"
        elif assessment['safety_level'] == 'WARNING':
            progression = "📈 Escalation detected - monitoring recommended"
        elif assessment['safety_level'] == 'DANGER':
            progression = "📈 High escalation - intervention may be needed"
        else:
            progression = "📈 Critical level reached"
        
        print(f"   Message: \"{message}\"")
        print(f"   Safety Level: {assessment['safety_level']}")
        print(f"   Risk Score: {assessment['overall_score']:.1%}")
        print(f"   {progression}")
        print()

def demo_performance_metrics():
    """Demonstrate performance characteristics."""
    print("📊 PERFORMANCE DEMONSTRATION")
    print("=" * 50)
    
    test_messages = [
        "Hi there!",  # Simple
        "I'm having a really difficult day and everything seems to be going wrong.",  # Medium
        "I can't believe how frustrating this is becoming. Every single time I try to do something, it fails and I'm getting really angry about the whole situation!"  # Complex
    ]
    
    print("Testing response times with different message complexities...")
    print()
    
    total_times = []
    
    for i, message in enumerate(test_messages, 1):
        print(f"Test {i}: {len(message)} characters")
        print(f"Message: \"{message[:50]}{'...' if len(message) > 50 else ''}\"")
        
        # Run multiple times for average
        times = []
        for _ in range(10):
            start_time = time.time()
            assessment = simple_safety_analysis(message)
            end_time = time.time()
            times.append(end_time - start_time)
        
        avg_time = sum(times) / len(times)
        total_times.extend(times)
        
        print(f"Average Response Time: {avg_time*1000:.2f}ms")
        print(f"Safety Level: {assessment['safety_level']}")
        print()
    
    overall_avg = sum(total_times) / len(total_times)
    print(f"📈 Overall Performance Summary:")
    print(f"   Average Response Time: {overall_avg*1000:.2f}ms")
    print(f"   Total Tests: {len(total_times)}")
    print(f"   Real-time Capable: {'✅ Yes' if overall_avg < 0.5 else '⚠️  Marginal' if overall_avg < 1.0 else '❌ No'}")
    print(f"   Chat Application Ready: {'✅ Yes' if overall_avg < 1.0 else '❌ No'}")
    print()

def demo_model_architecture():
    """Explain the model architecture."""
    print("🏗️  SYSTEM ARCHITECTURE OVERVIEW")
    print("=" * 50)
    
    print("The AI Safety Models system consists of four integrated models:")
    print()
    
    print("1. 🚫 ABUSE DETECTION MODEL")
    print("   • Identifies harmful, threatening, or inappropriate language")
    print("   • Uses hybrid ML + rule-based approach")
    print("   • TF-IDF vectorization + Logistic Regression")
    print("   • Real-time keyword filtering for rapid detection")
    print()
    
    print("2. 📈 ESCALATION DETECTION MODEL") 
    print("   • Tracks emotional escalation over conversation history")
    print("   • Sentiment trajectory analysis using TextBlob")
    print("   • Linguistic pattern recognition (repetition, intensity)")
    print("   • Temporal analysis for rapid-fire messaging")
    print()
    
    print("3. 🆘 CRISIS INTERVENTION MODEL")
    print("   • Detects self-harm indicators and mental health crises")
    print("   • Multi-category analysis (self-harm, despair, emergency)")
    print("   • Urgency level classification (Minimal → Critical)")
    print("   • Automatic intervention protocols for high-risk cases")
    print()
    
    print("4. 🔒 CONTENT FILTERING MODEL")
    print("   • Age-appropriate content filtering system")
    print("   • Support for Child (0-12), Teen (13-17), Adult (18+)")
    print("   • Violence and mature content level detection")
    print("   • Guardian controls and parental oversight")
    print()
    
    print("🔗 SAFETY COORDINATOR")
    print("   • Orchestrates all models for unified assessment")
    print("   • Weighted scoring system for overall risk calculation")
    print("   • Real-time processing with session management")
    print("   • Intervention triggers and alert generation")
    print()

def main():
    """Main demo function."""
    print_banner()
    
    print("This demonstration showcases the AI Safety Models POC capabilities")
    print("including real-time safety analysis and integrated model performance.")
    print()
    
    print("📋 DEMONSTRATION AGENDA:")
    print("1. Individual Safety Scenario Testing")
    print("2. Conversation Flow Analysis") 
    print("3. Performance Metrics")
    print("4. System Architecture Overview")
    print()
    
    input("Press Enter to start the demonstration...")
    print()
    
    try:
        # Run all demonstrations
        demo_individual_scenarios()
        
        input("Press Enter to continue to conversation flow demo...")
        demo_conversation_flow()
        
        input("Press Enter to continue to performance testing...")
        demo_performance_metrics()
        
        input("Press Enter to continue to architecture overview...")
        demo_model_architecture()
        
        print("🎉 DEMONSTRATION COMPLETE!")
        print("=" * 50)
        
        print("✅ Key Takeaways:")
        print("• Real-time safety analysis with <1ms response times")
        print("• Comprehensive coverage across 4 safety dimensions")
        print("• Escalation tracking over conversation history")
        print("• Crisis intervention with automatic protocols")
        print("• Age-appropriate content filtering")
        print("• Modular architecture for easy extension")
        print()
        
        print("🚀 Next Steps:")
        print("• Try the CLI interface: python src/cli_app.py")
        print("• Run full evaluation: python scripts/evaluate_models.py") 
        print("• Install dependencies for web interface:")
        print("  pip install flask scikit-learn pandas numpy nltk textblob")
        print("• Launch web app: python src/main.py → http://localhost:5000")
        print()
        
        print("📊 For the full system with all dependencies:")
        print("• Enhanced ML models with higher accuracy")
        print("• Web-based dashboard and monitoring")
        print("• Export capabilities for analysis")
        print("• Advanced escalation pattern detection")
        
    except KeyboardInterrupt:
        print("\n\n👋 Demo interrupted. Thank you for watching!")
    except Exception as e:
        print(f"\n❌ Demo error: {e}")

if __name__ == "__main__":
    main()