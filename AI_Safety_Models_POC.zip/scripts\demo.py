"""
Demo Script for AI Safety Models
Demonstrates the capabilities of the AI Safety Models system.
"""

import sys
import os
import time

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from utils.safety_coordinator import SafetyCoordinator
from models.abuse_detector import AbuseDetector
from models.escalation_detector import EscalationDetector
from models.crisis_detector import CrisisDetector
from models.content_filter import ContentFilter

def print_header(title):
    """Print a formatted header."""
    print("\n" + "="*60)
    print(f" {title.upper()} ")
    print("="*60)

def print_section(title):
    """Print a formatted section header."""
    print(f"\n{'-'*40}")
    print(f" {title}")
    print(f"{'-'*40}")

def demo_individual_models():
    """Demonstrate individual model capabilities."""
    print_header("Individual Models Demo")
    
    # Demo messages
    demo_messages = {
        'safe': "Hello, how are you today? I hope you're having a great day!",
        'abuse': "You're such an idiot! I hate you and you're completely worthless!",
        'escalation': "I'm getting really frustrated! This is the third time I've told you!",
        'crisis': "I feel so hopeless. Nobody would miss me if I was gone.",
        'inappropriate_child': "Let's talk about adult relationships and mature content."
    }
    
    # Initialize models
    abuse_detector = AbuseDetector()
    escalation_detector = EscalationDetector()
    crisis_detector = CrisisDetector()
    content_filter = ContentFilter()
    
    # Train abuse detector
    print("Training abuse detection model with sample data...")
    training_data = abuse_detector.get_sample_training_data()
    abuse_detector.train_model(training_data)
    print("✓ Abuse detector trained successfully")
    
    # Demo Abuse Detection
    print_section("Abuse Detection Demo")
    for category, message in [('safe', demo_messages['safe']), ('abuse', demo_messages['abuse'])]:
        result = abuse_detector.predict(message)
        print(f"\nMessage: \"{message}\"")
        print(f"Category: {category}")
        print(f"Is Abuse: {result['is_abuse']}")
        print(f"Confidence: {result['confidence']:.3f}")
        if result['explanation']:
            print(f"Explanation: {', '.join(result['explanation'])}")
    
    # Demo Escalation Detection
    print_section("Escalation Detection Demo")
    escalation_detector.reset_conversation()
    
    conversation = [
        "Hi there, I have a question.",
        "This isn't working as expected.",
        "I'm getting frustrated with this issue.",
        "Why isn't this working? This is really annoying!",
        demo_messages['escalation']
    ]
    
    for i, message in enumerate(conversation):
        result = escalation_detector.predict_escalation(message)
        print(f"\nMessage {i+1}: \"{message}\"")
        print(f"Is Escalating: {result['is_escalating']}")
        print(f"Escalation Score: {result['escalation_score']:.3f}")
        if result['explanation']:
            print(f"Explanation: {', '.join(result['explanation'])}")
    
    # Demo Crisis Detection
    print_section("Crisis Detection Demo")
    for category, message in [('safe', demo_messages['safe']), ('crisis', demo_messages['crisis'])]:
        result = crisis_detector.predict_crisis(message)
        print(f"\nMessage: \"{message}\"")
        print(f"Category: {category}")
        print(f"Is Crisis: {result['is_crisis']}")
        print(f"Crisis Score: {result['crisis_score']:.3f}")
        print(f"Urgency Level: {result['urgency_level']}")
        print(f"Intervention Needed: {result['intervention_needed']}")
        if result['explanation']:
            print(f"Explanation: {', '.join(result['explanation'])}")
    
    # Demo Content Filtering
    print_section("Content Filtering Demo")
    test_cases = [
        (demo_messages['safe'], 8, "Child"),
        (demo_messages['inappropriate_child'], 8, "Child"),
        (demo_messages['inappropriate_child'], 16, "Teen"),
        (demo_messages['inappropriate_child'], 25, "Adult")
    ]
    
    for message, age, age_category in test_cases:
        result = content_filter.filter_content(message, age)
        print(f"\nMessage: \"{message}\"")
        print(f"User Age: {age} ({age_category})")
        print(f"Is Appropriate: {result['is_appropriate']}")
        print(f"Appropriateness Score: {result['appropriateness_score']:.3f}")
        if result['block_reasons']:
            print(f"Block Reasons: {', '.join(result['block_reasons'])}")

def demo_integrated_system():
    """Demonstrate the integrated safety system."""
    print_header("Integrated Safety System Demo")
    
    # Initialize safety coordinator
    coordinator = SafetyCoordinator()
    print("Initializing integrated safety system...")
    
    success = coordinator.initialize_models()
    if not success:
        print("❌ Failed to initialize some models")
        return
    
    print("✓ All safety models initialized successfully")
    
    # Demo scenarios
    scenarios = [
        {
            'name': 'Normal Conversation',
            'message': 'Hello! I wanted to ask you about the weather today.',
            'user_age': 18,
            'expected_level': 'Safe'
        },
        {
            'name': 'Mild Frustration',
            'message': 'This is getting a bit annoying, but I understand.',
            'user_age': 16,
            'expected_level': 'Caution'
        },
        {
            'name': 'Abusive Language',
            'message': 'You\'re such an idiot! I hate dealing with you!',
            'user_age': 18,
            'expected_level': 'Warning/Danger'
        },
        {
            'name': 'Crisis Situation',
            'message': 'I feel so hopeless. I can\'t take this pain anymore and want to end it all.',
            'user_age': 20,
            'expected_level': 'Critical'
        },
        {
            'name': 'Age-Inappropriate Content (Child)',
            'message': 'Let\'s talk about violent movies with lots of blood and weapons.',
            'user_age': 8,
            'expected_level': 'Warning (Content Filter)'
        }
    ]
    
    print_section("Safety Assessment Scenarios")
    
    for i, scenario in enumerate(scenarios, 1):
        print(f"\n🔍 Scenario {i}: {scenario['name']}")
        print(f"Message: \"{scenario['message']}\"")
        print(f"User Age: {scenario['user_age']}")
        print(f"Expected Level: {scenario['expected_level']}")
        
        # Perform assessment
        start_time = time.time()
        assessment = coordinator.assess_content_safety(
            scenario['message'], 
            scenario['user_age']
        )
        end_time = time.time()
        
        # Display results
        print(f"\n📊 Assessment Results:")
        print(f"   Safety Level: {assessment.safety_level.value.upper()}")
        print(f"   Overall Score: {assessment.overall_score:.3f}")
        print(f"   Response Time: {(end_time - start_time)*1000:.1f}ms")
        print(f"   Intervention Required: {'Yes' if assessment.requires_intervention else 'No'}")
        
        if assessment.individual_scores:
            print(f"   Model Scores:")
            for model, score in assessment.individual_scores.items():
                print(f"     {model.replace('_', ' ').title()}: {score:.3f}")
        
        if assessment.alerts:
            print(f"   Alerts:")
            for alert in assessment.alerts[:3]:  # Show first 3 alerts
                print(f"     ⚠️  {alert}")
        
        if assessment.recommendations:
            print(f"   Recommendations:")
            for rec in assessment.recommendations[:2]:  # Show first 2 recommendations
                print(f"     💡 {rec}")
        
        print(f"   {'✅ Correct' if assessment.safety_level.value in scenario['expected_level'].lower() else '⚠️  Different from expected'}")

def demo_conversation_flow():
    """Demonstrate conversation flow with escalation detection."""
    print_header("Conversation Flow Demo")
    
    coordinator = SafetyCoordinator()
    coordinator.initialize_models()
    
    # Simulate an escalating conversation
    conversation = [
        "Hi, I need help with my account.",
        "The system keeps giving me errors.",
        "This is getting frustrating. Why isn't it working?",
        "I've been trying for an hour! This is ridiculous!",
        "This is absolutely terrible! You people are incompetent!",
        "I'm so angry I could scream! Fix this now or I'll complain!"
    ]
    
    print_section("Escalating Conversation Analysis")
    print("Analyzing a conversation that gradually escalates...")
    
    for i, message in enumerate(conversation, 1):
        print(f"\n💬 Message {i}: \"{message}\"")
        
        assessment = coordinator.assess_content_safety(message, user_age=25)
        
        print(f"   Safety Level: {assessment.safety_level.value.upper()}")
        print(f"   Overall Risk: {assessment.overall_score:.3f}")
        
        if 'escalation' in assessment.individual_scores:
            escalation_score = assessment.individual_scores['escalation']
            print(f"   Escalation Score: {escalation_score:.3f}")
        
        # Show progression
        if i == 1:
            print("   📈 Baseline conversation")
        elif assessment.safety_level.value == 'safe':
            print("   📈 Still within safe parameters")
        elif assessment.safety_level.value == 'caution':
            print("   📈 Showing signs of frustration")
        elif assessment.safety_level.value in ['warning', 'danger']:
            print("   📈 Escalation detected - intervention may be needed")
            
    print(f"\n📊 Conversation Summary:")
    report = coordinator.get_safety_report(include_history=True)
    if 'history' in report and 'recent_trends' in report['history']:
        trend = report['history']['recent_trends']
        print(f"   Trend Direction: {trend.get('trend_direction', 'unknown')}")
        print(f"   Average Risk: {trend.get('average_risk_score', 0):.3f}")

def demo_real_time_performance():
    """Demonstrate real-time performance capabilities."""
    print_header("Real-Time Performance Demo")
    
    coordinator = SafetyCoordinator()
    coordinator.initialize_models()
    
    print_section("Performance Benchmarking")
    
    # Test messages of varying complexity
    test_messages = [
        "Hi!",  # Simple
        "I'm having a really difficult day and everything seems to be going wrong.",  # Medium
        "I can't believe how frustrating this is becoming. Every single time I try to do something, it fails and I'm getting really angry about the whole situation!",  # Complex
    ]
    
    total_times = []
    
    for i, message in enumerate(test_messages, 1):
        print(f"\n⏱️  Test {i}: Message length {len(message)} characters")
        print(f"   Message: \"{message[:50]}{'...' if len(message) > 50 else ''}\"")
        
        # Multiple runs for average
        times = []
        for _ in range(5):
            start_time = time.time()
            assessment = coordinator.assess_content_safety(message, user_age=18)
            end_time = time.time()
            times.append(end_time - start_time)
        
        avg_time = sum(times) / len(times)
        total_times.extend(times)
        
        print(f"   Average Response Time: {avg_time*1000:.1f}ms")
        print(f"   Range: {min(times)*1000:.1f}ms - {max(times)*1000:.1f}ms")
        print(f"   Safety Level: {assessment.safety_level.value}")
    
    overall_avg = sum(total_times) / len(total_times)
    print(f"\n📊 Overall Performance:")
    print(f"   Average Response Time: {overall_avg*1000:.1f}ms")
    print(f"   Total Tests: {len(total_times)}")
    print(f"   Real-time Capable: {'Yes' if overall_avg < 0.5 else 'Marginal' if overall_avg < 1.0 else 'No'}")
    print(f"   Suitable for Chat: {'Yes' if overall_avg < 1.0 else 'No'}")

def main():
    """Main demo function."""
    print("🛡️  AI Safety Models - Comprehensive Demo")
    print("="*60)
    print("This demo showcases the capabilities of the AI Safety Models POC")
    print("including individual model performance and integrated system functionality.")
    
    try:
        # Run all demos
        demo_individual_models()
        demo_integrated_system()
        demo_conversation_flow()
        demo_real_time_performance()
        
        print_header("Demo Complete")
        print("✅ All demonstrations completed successfully!")
        print("\nKey Takeaways:")
        print("• Individual models work effectively for their specific domains")
        print("• Integrated system provides comprehensive safety analysis")
        print("• Real-time performance suitable for chat applications")
        print("• Escalation detection tracks conversation patterns over time")
        print("• Crisis detection identifies high-risk situations requiring intervention")
        print("• Content filtering ensures age-appropriate interactions")
        
        print(f"\n🚀 To run the web interface:")
        print("   cd src")
        print("   python main.py")
        print("   Open http://localhost:5000 in your browser")
        
    except Exception as e:
        print(f"\n❌ Demo failed with error: {e}")
        print("Please ensure all dependencies are installed:")
        print("   pip install -r requirements.txt")

if __name__ == "__main__":
    main()
