#!/usr/bin/env python3
"""
Live Chat Simulator for AI Safety Models

This script simulates a live chat environment with real-time safety monitoring.
It provides:
1. Multi-user chat simulation
2. Real-time safety analysis
3. Intervention protocols
4. Conversation monitoring
5. Data export capabilities
"""

import sys
import os
import time
import threading
import json
from datetime import datetime
from collections import deque
import random

# Add the src directory to Python path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

try:
    from utils.safety_coordinator import SafetyCoordinator
except ImportError as e:
    print(f"Import error: {e}")
    print("Using simplified simulation mode...")
    SafetyCoordinator = None

class ChatUser:
    """Represents a chat user with behavior patterns"""
    
    def __init__(self, name, age, behavior_type="normal"):
        self.name = name
        self.age = age
        self.behavior_type = behavior_type
        self.message_history = deque(maxlen=50)
        self.safety_history = deque(maxlen=20)
    
    def get_message_patterns(self):
        """Get message patterns based on behavior type"""
        patterns = {
            "normal": [
                "Hi everyone!",
                "How's everyone doing?",
                "That's interesting",
                "Thanks for sharing",
                "Have a great day!"
            ],
            "friendly": [
                "Hello there! 😊",
                "You're all awesome!",
                "Love chatting with you all",
                "Hope you're having a wonderful day",
                "This community is amazing!"
            ],
            "aggressive": [
                "You're all idiots",
                "This is stupid",
                "I hate this place",
                "Shut up everyone",
                "You don't know anything"
            ],
            "escalating": [
                "I'm getting annoyed",
                "This is really frustrating",
                "I'm so angry right now",
                "I can't take this anymore",
                "Everyone here is terrible"
            ],
            "crisis": [
                "I'm feeling really down",
                "Nobody understands me",
                "I don't see the point anymore",
                "I want this to end",
                "I can't go on like this"
            ],
            "inappropriate": [
                "Let's talk about violence",
                "I know how to make weapons",
                "Want to see something disturbing?",
                "This content isn't for kids",
                "Here's some adult material"
            ]
        }
        return patterns.get(self.behavior_type, patterns["normal"])
    
    def generate_message(self):
        """Generate a message based on user's behavior pattern"""
        patterns = self.get_message_patterns()
        return random.choice(patterns)

class LiveChatSimulator:
    """Simulates a live chat environment with safety monitoring"""
    
    def __init__(self):
        self.coordinator = None
        self.users = []
        self.chat_log = deque(maxlen=1000)
        self.safety_alerts = deque(maxlen=100)
        self.running = False
        self.chat_thread = None
        
        # Initialize safety coordinator
        try:
            if SafetyCoordinator:
                self.coordinator = SafetyCoordinator()
                print("✅ Safety monitoring initialized")
            else:
                print("⚠️ Using simplified safety monitoring")
        except Exception as e:
            print(f"⚠️ Safety coordinator error: {e}")
    
    def add_user(self, name, age, behavior_type="normal"):
        """Add a user to the chat"""
        user = ChatUser(name, age, behavior_type)
        self.users.append(user)
        print(f"👤 Added user: {name} (age {age}, behavior: {behavior_type})")
    
    def setup_default_users(self):
        """Setup default users with different behavior patterns"""
        default_users = [
            ("Alice", 16, "friendly"),
            ("Bob", 20, "normal"),
            ("Charlie", 14, "escalating"),
            ("Dana", 18, "aggressive"),
            ("Eve", 12, "crisis"),
            ("Frank", 22, "inappropriate")
        ]
        
        for name, age, behavior in default_users:
            self.add_user(name, age, behavior)
    
    def analyze_message_simple(self, message, user_age, user_name):
        """Simplified message analysis when coordinator is not available"""
        danger_words = ['hate', 'stupid', 'idiot', 'kill', 'hurt']
        crisis_words = ['end', 'die', 'can\'t go on', 'point anymore']
        inappropriate_words = ['violence', 'weapons', 'adult material']
        
        message_lower = message.lower()
        
        danger_score = sum(0.3 for word in danger_words if word in message_lower)
        crisis_score = sum(0.4 for word in crisis_words if word in message_lower)
        inappropriate_score = sum(0.2 for word in inappropriate_words if word in message_lower)
        
        overall_risk = min(danger_score + crisis_score + inappropriate_score, 1.0)
        
        if overall_risk >= 0.8:
            safety_level = "CRITICAL"
        elif overall_risk >= 0.6:
            safety_level = "DANGER"
        elif overall_risk >= 0.3:
            safety_level = "WARNING"
        else:
            safety_level = "SAFE"
        
        return {
            'message': message,
            'user_name': user_name,
            'user_age': user_age,
            'safety_level': safety_level,
            'overall_risk_score': overall_risk,
            'timestamp': datetime.now().strftime('%H:%M:%S'),
            'alerts': ['Potentially harmful content'] if overall_risk > 0.5 else []
        }
    
    def analyze_message(self, message, user_age, user_name):
        """Analyze message for safety concerns"""
        try:
            if self.coordinator:
                result = self.coordinator.analyze_message(message, user_age)
                result['user_name'] = user_name
                result['timestamp'] = datetime.now().strftime('%H:%M:%S')
                return result
            else:
                return self.analyze_message_simple(message, user_age, user_name)
        except Exception as e:
            print(f"Analysis error: {e}")
            return self.analyze_message_simple(message, user_age, user_name)
    
    def process_message(self, user, message):
        """Process a chat message and update logs"""
        # Analyze message safety
        analysis = self.analyze_message(message, user.age, user.name)
        
        # Add to chat log
        chat_entry = {
            'timestamp': analysis['timestamp'],
            'user': user.name,
            'age': user.age,
            'message': message,
            'safety_analysis': analysis
        }
        
        self.chat_log.append(chat_entry)
        user.message_history.append(message)
        user.safety_history.append(analysis)
        
        # Handle safety alerts
        if analysis['safety_level'] in ['DANGER', 'CRITICAL']:
            alert = {
                'timestamp': analysis['timestamp'],
                'user': user.name,
                'message': message,
                'safety_level': analysis['safety_level'],
                'risk_score': analysis['overall_risk_score']
            }
            self.safety_alerts.append(alert)
        
        return chat_entry
    
    def print_chat_message(self, chat_entry):
        """Print a formatted chat message"""
        analysis = chat_entry['safety_analysis']
        
        # Color coding for safety levels
        colors = {
            'SAFE': '\033[92m',      # Green
            'WARNING': '\033[93m',   # Yellow  
            'DANGER': '\033[91m',    # Red
            'CRITICAL': '\033[95m'   # Magenta
        }
        reset_color = '\033[0m'
        
        safety_color = colors.get(analysis['safety_level'], '')
        
        print(f"[{chat_entry['timestamp']}] {safety_color}{analysis['safety_level']:8s}{reset_color} | "
              f"{chat_entry['user']:10s} ({chat_entry['age']:2d}): {chat_entry['message']}")
        
        # Show alerts if any
        if analysis.get('alerts'):
            print(f"{'':25s} 🚨 {', '.join(analysis['alerts'])}")
    
    def chat_simulation_loop(self, duration=60, message_frequency=3):
        """Main chat simulation loop"""
        print(f"\n💬 Starting chat simulation for {duration} seconds...")
        print(f"📊 Message frequency: every ~{message_frequency} seconds")
        print("\n" + "="*80)
        
        start_time = time.time()
        
        while self.running and (time.time() - start_time) < duration:
            try:
                # Select random user to send message
                user = random.choice(self.users)
                message = user.generate_message()
                
                # Process the message
                chat_entry = self.process_message(user, message)
                
                # Display the message
                self.print_chat_message(chat_entry)
                
                # Wait before next message
                time.sleep(random.uniform(message_frequency * 0.5, message_frequency * 1.5))
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"Simulation error: {e}")
        
        self.running = False
        print("\n" + "="*80)
        print("💬 Chat simulation ended")
    
    def start_simulation(self, duration=60, message_frequency=3):
        """Start the chat simulation in a separate thread"""
        if self.running:
            print("❌ Simulation already running")
            return
        
        self.running = True
        self.chat_thread = threading.Thread(
            target=self.chat_simulation_loop,
            args=(duration, message_frequency)
        )
        self.chat_thread.start()
    
    def stop_simulation(self):
        """Stop the chat simulation"""
        self.running = False
        if self.chat_thread and self.chat_thread.is_alive():
            self.chat_thread.join()
    
    def print_safety_summary(self):
        """Print safety monitoring summary"""
        total_messages = len(self.chat_log)
        
        if total_messages == 0:
            print("No messages to analyze")
            return
        
        # Count safety levels
        safety_counts = {}
        risk_scores = []
        
        for entry in self.chat_log:
            analysis = entry['safety_analysis']
            level = analysis['safety_level']
            safety_counts[level] = safety_counts.get(level, 0) + 1
            risk_scores.append(analysis['overall_risk_score'])
        
        avg_risk = sum(risk_scores) / len(risk_scores)
        
        print(f"\n🛡️ SAFETY MONITORING SUMMARY")
        print("="*50)
        print(f"Total Messages: {total_messages}")
        print(f"Safety Alerts: {len(self.safety_alerts)}")
        print(f"Average Risk Score: {avg_risk:.3f}")
        print(f"\nSafety Level Distribution:")
        
        for level in ['SAFE', 'WARNING', 'DANGER', 'CRITICAL']:
            count = safety_counts.get(level, 0)
            percentage = (count / total_messages) * 100
            print(f"  {level:8s}: {count:3d} ({percentage:5.1f}%)")
        
        # Show recent alerts
        if self.safety_alerts:
            print(f"\n🚨 Recent Safety Alerts:")
            for alert in list(self.safety_alerts)[-5:]:
                print(f"  [{alert['timestamp']}] {alert['user']}: {alert['safety_level']} - {alert['message'][:50]}")
    
    def export_data(self, filename=None):
        """Export chat data and safety analysis"""
        if filename is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"chat_simulation_{timestamp}.json"
        
        data = {
            'simulation_info': {
                'total_messages': len(self.chat_log),
                'total_alerts': len(self.safety_alerts),
                'users': [{'name': u.name, 'age': u.age, 'behavior': u.behavior_type} for u in self.users]
            },
            'chat_log': list(self.chat_log),
            'safety_alerts': list(self.safety_alerts)
        }
        
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            print(f"📁 Data exported to: {filename}")
        except Exception as e:
            print(f"❌ Export error: {e}")
    
    def interactive_mode(self):
        """Interactive mode for manual testing"""
        print("\n💬 INTERACTIVE CHAT MODE")
        print("Commands: 'start [duration]', 'stop', 'summary', 'export', 'users', 'quit'")
        
        while True:
            try:
                command = input("\n> ").strip().lower()
                
                if command == 'quit':
                    break
                elif command == 'start':
                    duration = int(input("Duration (seconds, default 60): ") or "60")
                    self.start_simulation(duration)
                elif command.startswith('start '):
                    duration = int(command.split()[1])
                    self.start_simulation(duration)
                elif command == 'stop':
                    self.stop_simulation()
                elif command == 'summary':
                    self.print_safety_summary()
                elif command == 'export':
                    self.export_data()
                elif command == 'users':
                    print("Current users:")
                    for user in self.users:
                        print(f"  - {user.name} (age {user.age}, behavior: {user.behavior_type})")
                else:
                    print("Available commands: start, stop, summary, export, users, quit")
            
            except KeyboardInterrupt:
                break
            except ValueError:
                print("❌ Invalid input")
            except Exception as e:
                print(f"❌ Error: {e}")
        
        self.stop_simulation()

def main():
    """Main function"""
    simulator = LiveChatSimulator()
    
    print("\n💬 LIVE CHAT SIMULATOR FOR AI SAFETY MODELS")
    print("="*60)
    
    # Setup default users
    simulator.setup_default_users()
    
    print("\nSimulation modes:")
    print("1. Quick Demo (30 seconds)")
    print("2. Standard Simulation (60 seconds)")
    print("3. Extended Simulation (300 seconds)")
    print("4. Interactive Mode")
    print("5. Exit")
    
    try:
        choice = input("\nSelect mode (1-5): ").strip()
        
        if choice == '1':
            simulator.start_simulation(30, 2)
            simulator.chat_thread.join()
            simulator.print_safety_summary()
        elif choice == '2':
            simulator.start_simulation(60, 3)
            simulator.chat_thread.join()
            simulator.print_safety_summary()
        elif choice == '3':
            simulator.start_simulation(300, 4)
            simulator.chat_thread.join()
            simulator.print_safety_summary()
        elif choice == '4':
            simulator.interactive_mode()
        elif choice == '5':
            print("👋 Goodbye!")
        else:
            print("❌ Invalid choice")
    
    except KeyboardInterrupt:
        print("\n⏹️ Stopping simulation...")
        simulator.stop_simulation()
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()
