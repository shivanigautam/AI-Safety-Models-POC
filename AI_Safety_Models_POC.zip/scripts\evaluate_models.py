"""
Model Evaluation Script
Evaluates the performance of AI safety models using various metrics.
"""

import sys
import os
import time
import json
from typing import Dict, List, Tuple
import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from models.abuse_detector import AbuseDetector
from models.escalation_detector import EscalationDetector
from models.crisis_detector import CrisisDetector
from models.content_filter import ContentFilter, AgeGroup
from utils.data_preprocessor import DataPreprocessor
from utils.safety_coordinator import SafetyCoordinator

class ModelEvaluator:
    def __init__(self):
        self.abuse_detector = AbuseDetector()
        self.escalation_detector = EscalationDetector()
        self.crisis_detector = CrisisDetector()
        self.content_filter = ContentFilter()
        self.preprocessor = DataPreprocessor()
        
        self.evaluation_results = {}
    
    def create_test_datasets(self):
        """Create comprehensive test datasets for evaluation."""
        
        # Abuse Detection Test Data
        abuse_test_data = [
            # Non-abusive (label: 0)
            ("Hello, how are you today?", 0),
            ("I love this weather, it's so nice!", 0),
            ("Can you help me with this problem?", 0),
            ("Thank you for your assistance.", 0),
            ("Good morning everyone!", 0),
            ("I disagree with your opinion, but respect it.", 0),
            ("Let's work together on this project.", 0),
            ("That's an interesting perspective.", 0),
            ("I appreciate your help with this.", 0),
            ("Have a great day!", 0),
            
            # Abusive (label: 1)
            ("You are such an idiot, go away!", 1),
            ("I hate you so much, you're worthless!", 1),
            ("Shut up, you stupid moron!", 1),
            ("You're disgusting and pathetic!", 1),
            ("Nobody likes you, loser!", 1),
            ("Go kill yourself!", 1),
            ("You're the worst person ever!", 1),
            ("I'm going to hurt you badly!", 1),
            ("You make me sick, get lost!", 1),
            ("Die in a hole, scumbag!", 1),
        ]
        
        # Escalation Test Data
        escalation_test_data = [
            # Non-escalating conversations
            [
                ("Hi there!", 0),
                ("Hello! How can I help?", 0),
                ("I have a question about this.", 0),
                ("Sure, what's your question?", 0),
            ],
            # Escalating conversations
            [
                ("This isn't working right.", 0),
                ("I'm getting frustrated with this.", 1),
                ("Why isn't this working? This is annoying!", 1),
                ("I'm really angry now! Fix this immediately!", 1),
            ],
        ]
        
        # Crisis Test Data
        crisis_test_data = [
            # Non-crisis (label: 0)
            ("I'm having a tough day but I'll be okay.", 0),
            ("I'm feeling a bit sad today.", 0),
            ("Work has been stressful lately.", 0),
            ("I'm going through a difficult time.", 0),
            ("I feel overwhelmed but I'm managing.", 0),
            
            # Crisis (label: 1)
            ("I feel so hopeless, nothing matters anymore.", 1),
            ("I can't take this pain, I want to end it all.", 1),
            ("Nobody would miss me if I was gone.", 1),
            ("I'm planning to hurt myself tonight.", 1),
            ("Life isn't worth living anymore.", 1),
        ]
        
        # Content Filtering Test Data
        content_test_data = [
            # Child-appropriate content
            (("Let's learn about animals!", 8), True),
            (("I love playing with my toys.", 10), True),
            (("Math homework is fun!", 12), True),
            
            # Age-inappropriate content for children
            (("This movie has violence and blood.", 8), False),
            (("Let's talk about adult relationships.", 10), False),
            (("Have you tried drinking alcohol?", 12), False),
            
            # Teen-appropriate content
            (("I'm interested in dating someone.", 16), True),
            (("School relationships can be complicated.", 15), True),
            
            # Inappropriate for teens
            (("Let me show you explicit content.", 16), False),
            (("Want to see graphic violence?", 15), False),
        ]
        
        return {
            'abuse': abuse_test_data,
            'escalation': escalation_test_data,
            'crisis': crisis_test_data,
            'content': content_test_data
        }
    
    def evaluate_abuse_detection(self, test_data: List[Tuple[str, int]]) -> Dict:
        """Evaluate abuse detection model."""
        print("\n" + "="*50)
        print("EVALUATING ABUSE DETECTION MODEL")
        print("="*50)
        
        # Train model with sample data
        training_data = self.abuse_detector.get_sample_training_data()
        self.abuse_detector.train_model(training_data)
        
        # Make predictions
        y_true = []
        y_pred = []
        predictions_detail = []
        
        for text, true_label in test_data:
            result = self.abuse_detector.predict(text)
            predicted_label = 1 if result['is_abuse'] else 0
            
            y_true.append(true_label)
            y_pred.append(predicted_label)
            predictions_detail.append({
                'text': text,
                'true_label': true_label,
                'predicted_label': predicted_label,
                'confidence': result['confidence'],
                'correct': true_label == predicted_label
            })
        
        # Calculate metrics
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, zero_division=0)
        recall = recall_score(y_true, y_pred, zero_division=0)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        
        results = {
            'model': 'Abuse Detection',
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'test_samples': len(test_data),
            'predictions': predictions_detail,
            'classification_report': classification_report(y_true, y_pred, zero_division=0)
        }
        
        # Print results
        print(f"Accuracy:  {accuracy:.3f}")
        print(f"Precision: {precision:.3f}")
        print(f"Recall:    {recall:.3f}")
        print(f"F1-Score:  {f1:.3f}")
        print(f"\nClassification Report:")
        print(results['classification_report'])
        
        return results
    
    def evaluate_escalation_detection(self, test_conversations: List) -> Dict:
        """Evaluate escalation detection model."""
        print("\n" + "="*50)
        print("EVALUATING ESCALATION DETECTION MODEL")
        print("="*50)
        
        correct_predictions = 0
        total_predictions = 0
        escalation_scores = []
        
        for conversation in test_conversations:
            # Reset for each conversation
            self.escalation_detector.reset_conversation()
            
            for i, (message, expected_escalation) in enumerate(conversation):
                result = self.escalation_detector.predict_escalation(message)
                predicted_escalation = result['is_escalating']
                
                if i > 0:  # Skip first message as baseline
                    correct_predictions += (predicted_escalation == expected_escalation)
                    total_predictions += 1
                    escalation_scores.append(result['escalation_score'])
        
        accuracy = correct_predictions / total_predictions if total_predictions > 0 else 0
        avg_escalation_score = np.mean(escalation_scores) if escalation_scores else 0
        
        results = {
            'model': 'Escalation Detection',
            'accuracy': accuracy,
            'average_escalation_score': avg_escalation_score,
            'total_conversations': len(test_conversations),
            'total_predictions': total_predictions,
            'correct_predictions': correct_predictions
        }
        
        print(f"Accuracy: {accuracy:.3f}")
        print(f"Average Escalation Score: {avg_escalation_score:.3f}")
        print(f"Conversations Analyzed: {len(test_conversations)}")
        
        return results
    
    def evaluate_crisis_detection(self, test_data: List[Tuple[str, int]]) -> Dict:
        """Evaluate crisis detection model."""
        print("\n" + "="*50)
        print("EVALUATING CRISIS DETECTION MODEL")
        print("="*50)
        
        y_true = []
        y_pred = []
        crisis_scores = []
        intervention_needed = []
        
        for text, true_label in test_data:
            result = self.crisis_detector.predict_crisis(text)
            predicted_label = 1 if result['is_crisis'] else 0
            
            y_true.append(true_label)
            y_pred.append(predicted_label)
            crisis_scores.append(result['crisis_score'])
            intervention_needed.append(result['intervention_needed'])
        
        # Calculate metrics
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, zero_division=0)
        recall = recall_score(y_true, y_pred, zero_division=0)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        
        # Calculate intervention metrics
        high_priority_cases = sum(intervention_needed)
        avg_crisis_score = np.mean(crisis_scores)
        
        results = {
            'model': 'Crisis Detection',
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'average_crisis_score': avg_crisis_score,
            'intervention_cases': high_priority_cases,
            'test_samples': len(test_data)
        }
        
        print(f"Accuracy:  {accuracy:.3f}")
        print(f"Precision: {precision:.3f}")
        print(f"Recall:    {recall:.3f}")
        print(f"F1-Score:  {f1:.3f}")
        print(f"Average Crisis Score: {avg_crisis_score:.3f}")
        print(f"Cases Requiring Intervention: {high_priority_cases}")
        
        return results
    
    def evaluate_content_filtering(self, test_data: List) -> Dict:
        """Evaluate content filtering model."""
        print("\n" + "="*50)
        print("EVALUATING CONTENT FILTERING MODEL")
        print("="*50)
        
        correct_predictions = 0
        total_predictions = 0
        age_group_results = {}
        
        for (text, age), expected_appropriate in test_data:
            result = self.content_filter.filter_content(text, age)
            predicted_appropriate = result['is_appropriate']
            
            correct_predictions += (predicted_appropriate == expected_appropriate)
            total_predictions += 1
            
            # Track by age group
            if age <= 12:
                age_group = "child"
            elif age <= 17:
                age_group = "teen"
            else:
                age_group = "adult"
            
            if age_group not in age_group_results:
                age_group_results[age_group] = {'correct': 0, 'total': 0}
            
            age_group_results[age_group]['total'] += 1
            if predicted_appropriate == expected_appropriate:
                age_group_results[age_group]['correct'] += 1
        
        accuracy = correct_predictions / total_predictions if total_predictions > 0 else 0
        
        # Calculate age group accuracies
        for age_group in age_group_results:
            group_data = age_group_results[age_group]
            group_data['accuracy'] = group_data['correct'] / group_data['total'] if group_data['total'] > 0 else 0
        
        results = {
            'model': 'Content Filtering',
            'overall_accuracy': accuracy,
            'age_group_performance': age_group_results,
            'total_predictions': total_predictions,
            'correct_predictions': correct_predictions
        }
        
        print(f"Overall Accuracy: {accuracy:.3f}")
        for age_group, data in age_group_results.items():
            print(f"{age_group.capitalize()} Accuracy: {data['accuracy']:.3f} ({data['correct']}/{data['total']})")
        
        return results
    
    def evaluate_integration_performance(self) -> Dict:
        """Evaluate integrated system performance."""
        print("\n" + "="*50)
        print("EVALUATING INTEGRATED SYSTEM PERFORMANCE")
        print("="*50)
        
        coordinator = SafetyCoordinator()
        coordinator.initialize_models()
        
        # Test messages with expected safety levels
        test_cases = [
            ("Hello, how are you?", "safe"),
            ("I'm feeling frustrated about this.", "caution"),
            ("You're an idiot and I hate you!", "warning"),
            ("I want to hurt myself tonight.", "critical"),
            ("This content is inappropriate for kids.", "warning"),
        ]
        
        correct_assessments = 0
        response_times = []
        
        for message, expected_level in test_cases:
            start_time = time.time()
            assessment = coordinator.assess_content_safety(message, user_age=18)
            end_time = time.time()
            
            response_time = end_time - start_time
            response_times.append(response_time)
            
            # Map safety levels to general categories
            level_mapping = {
                'safe': 'safe',
                'caution': 'caution', 
                'warning': 'warning',
                'danger': 'warning',  # Group danger with warning
                'critical': 'critical'
            }
            
            predicted_category = level_mapping.get(assessment.safety_level.value, 'unknown')
            
            if predicted_category == expected_level:
                correct_assessments += 1
            
            print(f"Message: '{message[:50]}{'...' if len(message) > 50 else ''}'")
            print(f"  Expected: {expected_level}, Got: {predicted_category}")
            print(f"  Response time: {response_time:.3f}s")
            print()
        
        avg_response_time = np.mean(response_times)
        accuracy = correct_assessments / len(test_cases)
        
        results = {
            'model': 'Integrated System',
            'accuracy': accuracy,
            'average_response_time': avg_response_time,
            'max_response_time': max(response_times),
            'min_response_time': min(response_times),
            'total_tests': len(test_cases),
            'correct_assessments': correct_assessments
        }
        
        print(f"Integration Accuracy: {accuracy:.3f}")
        print(f"Average Response Time: {avg_response_time:.3f}s")
        print(f"Response Time Range: {min(response_times):.3f}s - {max(response_times):.3f}s")
        
        return results
    
    def run_comprehensive_evaluation(self):
        """Run comprehensive evaluation of all models."""
        print("STARTING COMPREHENSIVE AI SAFETY MODELS EVALUATION")
        print("="*60)
        
        # Create test datasets
        test_datasets = self.create_test_datasets()
        
        # Evaluate individual models
        self.evaluation_results['abuse_detection'] = self.evaluate_abuse_detection(test_datasets['abuse'])
        self.evaluation_results['escalation_detection'] = self.evaluate_escalation_detection(test_datasets['escalation'])
        self.evaluation_results['crisis_detection'] = self.evaluate_crisis_detection(test_datasets['crisis'])
        self.evaluation_results['content_filtering'] = self.evaluate_content_filtering(test_datasets['content'])
        
        # Evaluate integrated system
        self.evaluation_results['integration'] = self.evaluate_integration_performance()
        
        # Generate summary report
        self.generate_summary_report()
        
        return self.evaluation_results
    
    def generate_summary_report(self):
        """Generate summary evaluation report."""
        print("\n" + "="*60)
        print("EVALUATION SUMMARY REPORT")
        print("="*60)
        
        print("\nModel Performance Overview:")
        print("-" * 40)
        
        for model_name, results in self.evaluation_results.items():
            if model_name == 'integration':
                continue
                
            print(f"\n{results['model']}:")
            
            if 'accuracy' in results:
                print(f"  Accuracy: {results['accuracy']:.3f}")
            if 'precision' in results:
                print(f"  Precision: {results['precision']:.3f}")
            if 'recall' in results:
                print(f"  Recall: {results['recall']:.3f}")
            if 'f1_score' in results:
                print(f"  F1-Score: {results['f1_score']:.3f}")
        
        # Integration performance
        if 'integration' in self.evaluation_results:
            integration = self.evaluation_results['integration']
            print(f"\nIntegrated System Performance:")
            print(f"  Overall Accuracy: {integration['accuracy']:.3f}")
            print(f"  Average Response Time: {integration['average_response_time']:.3f}s")
            print(f"  Real-time Capable: {'Yes' if integration['average_response_time'] < 1.0 else 'No'}")
        
        print(f"\nEvaluation completed at: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Save results to file
        self.save_evaluation_results()
    
    def save_evaluation_results(self):
        """Save evaluation results to JSON file."""
        try:
            # Create results directory
            results_dir = os.path.join(os.path.dirname(__file__), '..', 'data', 'evaluation_results')
            os.makedirs(results_dir, exist_ok=True)
            
            # Generate filename with timestamp
            timestamp = time.strftime('%Y%m%d_%H%M%S')
            filename = f'evaluation_results_{timestamp}.json'
            filepath = os.path.join(results_dir, filename)
            
            # Prepare results for JSON serialization
            json_results = {}
            for model_name, results in self.evaluation_results.items():
                json_results[model_name] = {}
                for key, value in results.items():
                    if key == 'predictions':
                        continue  # Skip detailed predictions to keep file manageable
                    if isinstance(value, np.float64):
                        json_results[model_name][key] = float(value)
                    elif isinstance(value, np.int64):
                        json_results[model_name][key] = int(value)
                    else:
                        json_results[model_name][key] = value
            
            # Add metadata
            json_results['metadata'] = {
                'evaluation_timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
                'evaluator_version': '1.0',
                'total_models_evaluated': len(self.evaluation_results)
            }
            
            # Save to file
            with open(filepath, 'w') as f:
                json.dump(json_results, f, indent=2)
            
            print(f"\nEvaluation results saved to: {filepath}")
            
        except Exception as e:
            print(f"Error saving evaluation results: {e}")

def main():
    """Main evaluation function."""
    evaluator = ModelEvaluator()
    results = evaluator.run_comprehensive_evaluation()
    
    print("\n" + "="*60)
    print("EVALUATION COMPLETE!")
    print("="*60)
    print("Check the generated report file for detailed results.")
    
    return results

if __name__ == "__main__":
    main()
