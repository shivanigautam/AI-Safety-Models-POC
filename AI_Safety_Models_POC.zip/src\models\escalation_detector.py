"""
Escalation Pattern Recognition Model
Detects when conversations are becoming emotionally dangerous through 
repeated aggressive language or intensifying negativity.
"""

import numpy as np
from typing import Dict, List, Tuple
from collections import deque
import re
from textblob import TextBlob

class EscalationDetector:
    def __init__(self):
        self.conversation_history = deque(maxlen=10)  # Keep last 10 messages
        self.escalation_threshold = 0.6
        self.escalation_indicators = {
            'repetitive_negative': ['again', 'always', 'never', 'every time'],
            'intensity_words': ['very', 'extremely', 'absolutely', 'totally', 'completely'],
            'frustration_markers': ['why', 'how can', 'what the', 'this is'],
            'aggressive_patterns': ['you always', 'you never', 'i told you', 'listen to me']
        }
    
    def preprocess_text(self, text: str) -> str:
        """Clean and preprocess text for analysis."""
        text = text.lower()
        text = re.sub(r'[^a-zA-Z0-9\s]', ' ', text)
        text = ' '.join(text.split())
        return text
    
    def analyze_sentiment_trajectory(self) -> Dict[str, float]:
        """Analyze sentiment changes over conversation history."""
        if len(self.conversation_history) < 2:
            return {'trajectory_score': 0.0, 'current_sentiment': 0.0}
        
        sentiments = []
        for message in self.conversation_history:
            try:
                blob = TextBlob(message['text'])
                sentiment = blob.sentiment.polarity  # -1 to 1
                sentiments.append(sentiment)
            except:
                sentiments.append(0.0)
        
        # Calculate trajectory (how sentiment changes)
        trajectory_score = 0.0
        if len(sentiments) >= 2:
            # Check if sentiment is getting progressively more negative
            negative_trend = 0
            for i in range(1, len(sentiments)):
                if sentiments[i] < sentiments[i-1]:
                    negative_trend += 1
            
            trajectory_score = negative_trend / (len(sentiments) - 1)
        
        current_sentiment = sentiments[-1] if sentiments else 0.0
        
        return {
            'trajectory_score': trajectory_score,
            'current_sentiment': current_sentiment,
            'sentiment_history': sentiments
        }
    
    def detect_repetitive_patterns(self, text: str) -> float:
        """Detect repetitive negative patterns in recent messages."""
        processed_text = self.preprocess_text(text)
        
        # Check for repetitive negative phrases
        repetitive_score = 0.0
        recent_texts = [msg['text'] for msg in list(self.conversation_history)[-3:]]
        
        for prev_text in recent_texts:
            prev_processed = self.preprocess_text(prev_text)
            # Check for similar phrases or repeated keywords
            common_words = set(processed_text.split()) & set(prev_processed.split())
            if len(common_words) > 2:
                repetitive_score += 0.3
        
        return min(repetitive_score, 1.0)
    
    def analyze_linguistic_escalation(self, text: str) -> Dict[str, float]:
        """Analyze linguistic patterns indicating escalation."""
        processed_text = self.preprocess_text(text)
        words = processed_text.split()
        
        scores = {
            'repetitive_negative': 0.0,
            'intensity': 0.0,
            'frustration': 0.0,
            'aggressive_patterns': 0.0
        }
        
        # Check for escalation indicators
        for category, indicators in self.escalation_indicators.items():
            matches = 0
            for indicator in indicators:
                if indicator in processed_text:
                    matches += 1
            
            if matches > 0:
                scores[category] = min(matches / len(indicators), 1.0)
        
        # Check for caps (indicating shouting)
        caps_ratio = sum(1 for c in text if c.isupper()) / max(len(text), 1)
        if caps_ratio > 0.3:
            scores['intensity'] += 0.4
        
        # Check for repeated punctuation (!!! or ???)
        if re.search(r'[!?]{3,}', text):
            scores['intensity'] += 0.3
        
        return scores
    
    def analyze_temporal_patterns(self) -> float:
        """Analyze timing patterns that might indicate escalation."""
        if len(self.conversation_history) < 3:
            return 0.0
        
        # Check for rapid-fire messages (short time intervals)
        rapid_messages = 0
        for i in range(1, len(self.conversation_history)):
            curr_time = self.conversation_history[i]['timestamp']
            prev_time = self.conversation_history[i-1]['timestamp']
            
            # If messages are less than 5 seconds apart, consider it rapid
            if curr_time - prev_time < 5:
                rapid_messages += 1
        
        if len(self.conversation_history) > 1:
            return rapid_messages / (len(self.conversation_history) - 1)
        
        return 0.0
    
    def add_message(self, text: str, timestamp: float = None):
        """Add a message to conversation history."""
        import time
        if timestamp is None:
            timestamp = time.time()
        
        self.conversation_history.append({
            'text': text,
            'timestamp': timestamp
        })
    
    def predict_escalation(self, text: str, timestamp: float = None) -> Dict[str, float]:
        """Predict escalation risk for current message."""
        # Add current message to history
        self.add_message(text, timestamp)
        
        # Analyze different aspects
        sentiment_analysis = self.analyze_sentiment_trajectory()
        linguistic_analysis = self.analyze_linguistic_escalation(text)
        repetitive_score = self.detect_repetitive_patterns(text)
        temporal_score = self.analyze_temporal_patterns()
        
        # Calculate overall escalation score
        escalation_score = 0.0
        
        # Sentiment trajectory weight (30%)
        if sentiment_analysis['trajectory_score'] > 0.5:
            escalation_score += sentiment_analysis['trajectory_score'] * 0.3
        
        # Current sentiment weight (20%)
        if sentiment_analysis['current_sentiment'] < -0.3:
            escalation_score += abs(sentiment_analysis['current_sentiment']) * 0.2
        
        # Linguistic patterns weight (30%)
        max_linguistic_score = max(linguistic_analysis.values())
        escalation_score += max_linguistic_score * 0.3
        
        # Repetitive patterns weight (10%)
        escalation_score += repetitive_score * 0.1
        
        # Temporal patterns weight (10%)
        escalation_score += temporal_score * 0.1
        
        is_escalating = escalation_score > self.escalation_threshold
        
        result = {
            'is_escalating': is_escalating,
            'escalation_score': min(escalation_score, 1.0),
            'sentiment_analysis': sentiment_analysis,
            'linguistic_analysis': linguistic_analysis,
            'repetitive_score': repetitive_score,
            'temporal_score': temporal_score,
            'explanation': []
        }
        
        # Generate explanations
        if sentiment_analysis['trajectory_score'] > 0.5:
            result['explanation'].append("Sentiment is becoming increasingly negative")
        
        if sentiment_analysis['current_sentiment'] < -0.5:
            result['explanation'].append("Current message shows strong negative sentiment")
        
        if max_linguistic_score > 0.4:
            result['explanation'].append("Detected aggressive or frustrated language patterns")
        
        if repetitive_score > 0.3:
            result['explanation'].append("Repetitive negative patterns detected")
        
        if temporal_score > 0.5:
            result['explanation'].append("Rapid message frequency indicates heightened emotion")
        
        return result
    
    def reset_conversation(self):
        """Reset conversation history."""
        self.conversation_history.clear()
    
    def get_conversation_summary(self) -> Dict:
        """Get summary of current conversation state."""
        return {
            'message_count': len(self.conversation_history),
            'recent_messages': list(self.conversation_history)[-3:],
            'average_sentiment': np.mean([
                TextBlob(msg['text']).sentiment.polarity 
                for msg in self.conversation_history
            ]) if self.conversation_history else 0.0
        }
