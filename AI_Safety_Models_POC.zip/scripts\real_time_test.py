#!/usr/bin/env python3
"""
Real-time AI Safety Models Testing System

This script provides comprehensive real-time testing capabilities:
1. Live data input and analysis
2. Streaming conversation simulation
3. Performance benchmarking
4. Real-time safety monitoring
5. Interactive testing modes
"""

import sys
import os
import time
import threading
import json
from datetime import datetime
from collections import deque
import random

# Add the src directory to Python path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

try:
    from utils.safety_coordinator import SafetyCoordinator
    from models.abuse_detector import AbuseDetector
    from models.escalation_detector import EscalationDetector
    from models.crisis_detector import CrisisDetector
    from models.content_filter import ContentFilter
except ImportError as e:
    print(f"Import error: {e}")
    print("Using simplified analysis mode...")
    SafetyCoordinator = None

class RealTimeTestSystem:
    """Real-time testing system for AI Safety Models"""
    
    def __init__(self):
        self.coordinator = None
        self.test_results = deque(maxlen=1000)  # Store last 1000 results
        self.performance_metrics = {
            'total_messages': 0,
            'total_time': 0,
            'avg_response_time': 0,
            'safety_alerts': 0,
            'crisis_interventions': 0
        }
        self.running = False
        
        # Initialize safety coordinator if available
        try:
            if SafetyCoordinator:
                self.coordinator = SafetyCoordinator()
                print("✅ AI Safety Models initialized successfully")
            else:
                print("⚠️ Using simplified mode (AI models not available)")
        except Exception as e:
            print(f"⚠️ Model initialization failed: {e}")
            print("Using simplified analysis mode...")
    
    def analyze_message_simple(self, message, user_age=18):
        """Simplified analysis when models aren't available"""
        # Basic keyword analysis
        danger_words = ['kill', 'die', 'hate', 'stupid', 'idiot', 'hurt', 'harm']
        crisis_words = ['suicide', 'end it', 'kill myself', 'want to die', 'no point']
        
        message_lower = message.lower()
        
        # Calculate basic risk scores
        danger_score = sum(1 for word in danger_words if word in message_lower) * 0.3
        crisis_score = sum(1 for word in crisis_words if word in message_lower) * 0.4
        
        overall_risk = min(danger_score + crisis_score, 1.0)
        
        # Determine safety level
        if overall_risk >= 0.8:
            safety_level = "CRITICAL"
        elif overall_risk >= 0.6:
            safety_level = "DANGER"
        elif overall_risk >= 0.3:
            safety_level = "WARNING"
        else:
            safety_level = "SAFE"
        
        return {
            'message': message,
            'user_age': user_age,
            'safety_level': safety_level,
            'overall_risk_score': overall_risk,
            'analysis_time': random.uniform(0.05, 0.15),  # Simulated response time
            'alerts': ['High-risk keywords detected'] if overall_risk > 0.5 else [],
            'recommendations': ['Monitor conversation closely'] if overall_risk > 0.3 else [],
            'model_scores': {
                'abuse_detection': danger_score,
                'crisis_detection': crisis_score,
                'escalation_level': min(overall_risk, 0.8),
                'content_appropriateness': 1.0 - overall_risk
            }
        }
    
    def analyze_message(self, message, user_age=18):
        """Analyze a message using AI Safety Models"""
        start_time = time.time()
        
        try:
            if self.coordinator:
                # Use full AI analysis
                result = self.coordinator.analyze_message(message, user_age)
                analysis_time = time.time() - start_time
                result['analysis_time'] = analysis_time
                return result
            else:
                # Use simplified analysis
                return self.analyze_message_simple(message, user_age)
        except Exception as e:
            print(f"Analysis error: {e}")
            return self.analyze_message_simple(message, user_age)
    
    def update_metrics(self, result):
        """Update performance metrics"""
        self.performance_metrics['total_messages'] += 1
        self.performance_metrics['total_time'] += result['analysis_time']
        self.performance_metrics['avg_response_time'] = (
            self.performance_metrics['total_time'] / self.performance_metrics['total_messages']
        )
        
        if result['safety_level'] in ['DANGER', 'CRITICAL']:
            self.performance_metrics['safety_alerts'] += 1
        
        if result['safety_level'] == 'CRITICAL':
            self.performance_metrics['crisis_interventions'] += 1
    
    def print_analysis_result(self, result):
        """Print formatted analysis result"""
        print(f"\n{'='*60}")
        print(f"📝 Message: {result['message']}")
        print(f"👤 User Age: {result['user_age']}")
        print(f"🛡️ Safety Level: {result['safety_level']}")
        print(f"📊 Risk Score: {result['overall_risk_score']:.3f}")
        print(f"⏱️ Analysis Time: {result['analysis_time']:.3f}s")
        
        if result.get('alerts'):
            print(f"🚨 Alerts: {', '.join(result['alerts'])}")
        
        if result.get('recommendations'):
            print(f"💡 Recommendations: {', '.join(result['recommendations'])}")
        
        if result.get('model_scores'):
            print("\n🔍 Model Breakdown:")
            for model, score in result['model_scores'].items():
                print(f"  • {model.replace('_', ' ').title()}: {score:.3f}")
        
        print(f"{'='*60}")
    
    def print_performance_summary(self):
        """Print current performance metrics"""
        metrics = self.performance_metrics
        print(f"\n📊 PERFORMANCE SUMMARY")
        print(f"{'='*40}")
        print(f"Total Messages Analyzed: {metrics['total_messages']}")
        print(f"Average Response Time: {metrics['avg_response_time']:.3f}s")
        print(f"Safety Alerts Generated: {metrics['safety_alerts']}")
        print(f"Crisis Interventions: {metrics['crisis_interventions']}")
        print(f"Messages/Second: {1/metrics['avg_response_time']:.1f}" if metrics['avg_response_time'] > 0 else "N/A")
        print(f"{'='*40}")
    
    def interactive_mode(self):
        """Interactive real-time testing mode"""
        print("\n🚀 REAL-TIME INTERACTIVE TESTING MODE")
        print("Type messages to analyze in real-time. Commands:")
        print("  'age X' - Set user age to X")
        print("  'stats' - Show performance statistics")
        print("  'quit' - Exit interactive mode")
        print("  'help' - Show this help")
        
        user_age = 18
        
        while True:
            try:
                message = input("\n💬 Enter message: ").strip()
                
                if not message:
                    continue
                
                # Handle commands
                if message.lower() == 'quit':
                    break
                elif message.lower() == 'help':
                    print("Commands: 'age X', 'stats', 'quit', 'help'")
                    continue
                elif message.lower() == 'stats':
                    self.print_performance_summary()
                    continue
                elif message.lower().startswith('age '):
                    try:
                        new_age = int(message.split()[1])
                        user_age = new_age
                        print(f"✅ User age set to {user_age}")
                    except (IndexError, ValueError):
                        print("❌ Invalid age format. Use 'age 18'")
                    continue
                
                # Analyze message
                result = self.analyze_message(message, user_age)
                self.test_results.append(result)
                self.update_metrics(result)
                self.print_analysis_result(result)
                
            except KeyboardInterrupt:
                print("\n\n⏹️ Stopping interactive mode...")
                break
            except Exception as e:
                print(f"❌ Error: {e}")
        
        self.print_performance_summary()
    
    def stress_test(self, num_messages=100):
        """Stress test with multiple messages"""
        print(f"\n🔥 STRESS TEST MODE - {num_messages} messages")
        
        test_messages = [
            "Hello, how are you?",
            "You're such an idiot!",
            "I hate everything about this",
            "I want to end it all",
            "This is inappropriate content",
            "Can you help me with homework?",
            "I'm feeling really depressed",
            "Go kill yourself",
            "What a beautiful day!",
            "I'm going to hurt someone"
        ]
        
        start_time = time.time()
        results = []
        
        for i in range(num_messages):
            message = random.choice(test_messages)
            age = random.choice([8, 12, 15, 18, 25])
            
            result = self.analyze_message(message, age)
            results.append(result)
            self.update_metrics(result)
            
            # Show progress
            if (i + 1) % 10 == 0:
                print(f"Processed {i + 1}/{num_messages} messages...")
        
        total_time = time.time() - start_time
        
        print(f"\n✅ STRESS TEST COMPLETE")
        print(f"Total Time: {total_time:.3f}s")
        print(f"Messages/Second: {num_messages/total_time:.1f}")
        
        self.print_performance_summary()
        
        # Show distribution of safety levels
        safety_counts = {}
        for result in results:
            level = result['safety_level']
            safety_counts[level] = safety_counts.get(level, 0) + 1
        
        print(f"\n🛡️ SAFETY LEVEL DISTRIBUTION:")
        for level, count in safety_counts.items():
            print(f"  {level}: {count} ({count/len(results)*100:.1f}%)")
    
    def streaming_test(self, duration=30):
        """Simulate streaming real-time data for specified duration"""
        print(f"\n📡 STREAMING TEST MODE - {duration} seconds")
        
        conversation_scenarios = [
            ["Hi there!", "How are you doing?", "That's great to hear!"],
            ["You're annoying", "I hate talking to you", "Just shut up already!"],
            ["I'm feeling sad", "Nobody understands me", "I don't want to live anymore"],
            ["Can we talk about violence?", "I want to hurt people", "Let's plan something bad"]
        ]
        
        start_time = time.time()
        message_count = 0
        
        while time.time() - start_time < duration:
            # Select random conversation scenario
            scenario = random.choice(conversation_scenarios)
            message = random.choice(scenario)
            age = random.choice([8, 12, 15, 18, 25])
            
            result = self.analyze_message(message, age)
            self.update_metrics(result)
            message_count += 1
            
            # Print abbreviated result
            print(f"[{message_count:3d}] {result['safety_level']:8s} | {message[:40]:<40} | {result['analysis_time']:.3f}s")
            
            # Simulate realistic message frequency (1-3 seconds between messages)
            time.sleep(random.uniform(1.0, 3.0))
        
        print(f"\n✅ STREAMING TEST COMPLETE")
        self.print_performance_summary()

def main():
    """Main function to run real-time testing"""
    system = RealTimeTestSystem()
    
    print("\n🛡️ AI SAFETY MODELS - REAL-TIME TESTING SYSTEM")
    print("="*60)
    
    while True:
        print("\nSelect testing mode:")
        print("1. Interactive Mode (type messages manually)")
        print("2. Stress Test (batch processing)")
        print("3. Streaming Test (simulated real-time data)")
        print("4. Performance Summary")
        print("5. Exit")
        
        try:
            choice = input("\nEnter choice (1-5): ").strip()
            
            if choice == '1':
                system.interactive_mode()
            elif choice == '2':
                num_msg = input("Number of messages (default 100): ").strip()
                num_msg = int(num_msg) if num_msg else 100
                system.stress_test(num_msg)
            elif choice == '3':
                duration = input("Duration in seconds (default 30): ").strip()
                duration = int(duration) if duration else 30
                system.streaming_test(duration)
            elif choice == '4':
                system.print_performance_summary()
            elif choice == '5':
                print("\n👋 Goodbye!")
                break
            else:
                print("❌ Invalid choice. Please select 1-5.")
        
        except KeyboardInterrupt:
            print("\n\n⏹️ Exiting...")
            break
        except ValueError:
            print("❌ Invalid input. Please enter a number.")
        except Exception as e:
            print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()
