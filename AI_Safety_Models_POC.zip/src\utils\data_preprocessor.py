"""
Data Preprocessor
Utilities for cleaning and preprocessing text data for AI safety models.
"""

import re
import string
import nltk
from typing import List, Dict, Tuple
import numpy as np

class DataPreprocessor:
    def __init__(self):
        # Download required NLTK data if not already present
        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('punkt', quiet=True)
        
        try:
            nltk.data.find('corpora/stopwords')
        except LookupError:
            nltk.download('stopwords', quiet=True)
        
        from nltk.corpus import stopwords
        self.stop_words = set(stopwords.words('english'))
        
    def basic_clean(self, text: str) -> str:
        """Basic text cleaning - remove extra spaces, normalize case."""
        if not isinstance(text, str):
            return ""
        
        # Remove extra whitespace
        text = ' '.join(text.split())
        return text.strip()
    
    def normalize_text(self, text: str, lowercase: bool = True) -> str:
        """Normalize text by handling case, punctuation, etc."""
        text = self.basic_clean(text)
        
        if lowercase:
            text = text.lower()
        
        return text
    
    def remove_special_characters(self, text: str, keep_punctuation: bool = False) -> str:
        """Remove special characters, optionally keeping basic punctuation."""
        if keep_punctuation:
            # Keep basic punctuation for sentence structure
            text = re.sub(r'[^\w\s.,!?;:\'-]', ' ', text)
        else:
            # Remove all special characters except spaces
            text = re.sub(r'[^\w\s]', ' ', text)
        
        # Clean up extra spaces
        text = ' '.join(text.split())
        return text
    
    def handle_contractions(self, text: str) -> str:
        """Expand common English contractions."""
        contractions = {
            "don't": "do not",
            "won't": "will not",
            "can't": "cannot",
            "n't": " not",
            "'re": " are",
            "'ve": " have",
            "'ll": " will",
            "'d": " would",
            "'m": " am",
            "let's": "let us",
            "that's": "that is",
            "who's": "who is",
            "what's": "what is",
            "where's": "where is",
            "how's": "how is",
            "it's": "it is",
            "he's": "he is",
            "she's": "she is"
        }
        
        for contraction, expansion in contractions.items():
            text = text.replace(contraction, expansion)
            # Also handle capitalized versions
            text = text.replace(contraction.capitalize(), expansion.capitalize())
        
        return text
    
    def remove_stopwords(self, text: str) -> str:
        """Remove common English stopwords."""
        words = text.split()
        filtered_words = [word for word in words if word.lower() not in self.stop_words]
        return ' '.join(filtered_words)
    
    def handle_repeated_characters(self, text: str) -> str:
        """Handle repeated characters (e.g., 'sooooo' -> 'so')."""
        # Replace 3+ repeated characters with 2
        text = re.sub(r'(.)\1{2,}', r'\1\1', text)
        return text
    
    def extract_features(self, text: str) -> Dict[str, float]:
        """Extract linguistic features from text."""
        features = {}
        
        # Length features
        features['char_count'] = len(text)
        features['word_count'] = len(text.split())
        features['sentence_count'] = len(re.findall(r'[.!?]+', text))
        
        # Average word length
        words = text.split()
        features['avg_word_length'] = np.mean([len(word) for word in words]) if words else 0
        
        # Punctuation features
        features['exclamation_count'] = text.count('!')
        features['question_count'] = text.count('?')
        features['caps_ratio'] = sum(1 for c in text if c.isupper()) / max(len(text), 1)
        
        # Special character patterns
        features['repeated_punctuation'] = len(re.findall(r'[!?]{2,}', text))
        features['repeated_chars'] = len(re.findall(r'(.)\1{2,}', text))
        
        return features
    
    def preprocess_for_abuse_detection(self, text: str) -> str:
        """Specialized preprocessing for abuse detection."""
        text = self.normalize_text(text, lowercase=True)
        text = self.handle_contractions(text)
        text = self.handle_repeated_characters(text)
        text = self.remove_special_characters(text, keep_punctuation=False)
        return text
    
    def preprocess_for_escalation_detection(self, text: str) -> str:
        """Specialized preprocessing for escalation detection."""
        text = self.normalize_text(text, lowercase=True)
        text = self.handle_contractions(text)
        # Keep some punctuation for escalation analysis
        text = self.remove_special_characters(text, keep_punctuation=True)
        return text
    
    def preprocess_for_crisis_detection(self, text: str) -> str:
        """Specialized preprocessing for crisis detection."""
        # More conservative preprocessing to preserve important phrases
        text = self.basic_clean(text)
        text = text.lower()
        text = self.handle_contractions(text)
        # Keep punctuation that might be important for crisis detection
        text = re.sub(r'[^\w\s.,!?;:\'-]', ' ', text)
        return text
    
    def preprocess_for_content_filtering(self, text: str) -> str:
        """Specialized preprocessing for content filtering."""
        text = self.normalize_text(text, lowercase=True)
        text = self.handle_contractions(text)
        text = self.remove_special_characters(text, keep_punctuation=False)
        return text
    
    def batch_preprocess(self, texts: List[str], preprocess_type: str = 'general') -> List[str]:
        """Preprocess a batch of texts."""
        preprocessors = {
            'general': self.normalize_text,
            'abuse': self.preprocess_for_abuse_detection,
            'escalation': self.preprocess_for_escalation_detection,
            'crisis': self.preprocess_for_crisis_detection,
            'content': self.preprocess_for_content_filtering
        }
        
        preprocessor = preprocessors.get(preprocess_type, self.normalize_text)
        return [preprocessor(text) for text in texts]
    
    def create_training_data_sample(self) -> List[Tuple[str, int]]:
        """Create sample training data for demonstration purposes."""
        # This would typically load from real datasets
        sample_data = [
            # Safe content (label: 0)
            ("Hello, how are you doing today?", 0),
            ("I love spending time with my family.", 0),
            ("Can you help me with my homework?", 0),
            ("The weather is really nice today!", 0),
            ("I'm excited about the weekend plans.", 0),
            
            # Potentially unsafe content (label: 1)
            ("You're such an idiot, I hate you!", 1),
            ("I'm going to hurt you badly.", 1),
            ("Nobody cares about me, I want to die.", 1),
            ("This is inappropriate content for children.", 1),
            ("I feel hopeless and want to end it all.", 1),
        ]
        
        return sample_data
    
    def validate_preprocessing(self, original: str, processed: str) -> Dict[str, bool]:
        """Validate that preprocessing didn't lose important information."""
        validation = {
            'length_reasonable': len(processed) > len(original) * 0.3,  # Not too much content lost
            'has_content': len(processed.strip()) > 0,  # Still has content
            'no_excessive_spaces': '  ' not in processed,  # No double spaces
        }
        
        return validation
