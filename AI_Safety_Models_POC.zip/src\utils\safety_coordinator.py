"""
Safety Coordinator
Coordinates all AI safety models and manages overall safety assessment.
"""

import time
import json
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum

class SafetyLevel(Enum):
    SAFE = "safe"
    CAUTION = "caution"  
    WARNING = "warning"
    DANGER = "danger"
    CRITICAL = "critical"

@dataclass
class SafetyAssessment:
    safety_level: SafetyLevel
    overall_score: float
    individual_scores: Dict[str, float]
    alerts: List[str]
    recommendations: List[str]
    requires_intervention: bool
    timestamp: float

class SafetyCoordinator:
    def __init__(self):
        self.abuse_detector = None
        self.escalation_detector = None  
        self.crisis_detector = None
        self.content_filter = None
        
        # Safety thresholds
        self.thresholds = {
            'abuse': 0.7,
            'escalation': 0.6,
            'crisis': 0.8,
            'content_inappropriate': 0.5
        }
        
        # Weight importance of different models
        self.model_weights = {
            'abuse': 0.25,
            'escalation': 0.25,
            'crisis': 0.35,  # Crisis detection gets higher weight
            'content': 0.15
        }
        
        self.assessment_history = []
        
    def initialize_models(self):
        """Initialize all safety models."""
        try:
            from src.models.abuse_detector import AbuseDetector
            from src.models.escalation_detector import EscalationDetector
            from src.models.crisis_detector import CrisisDetector
            from src.models.content_filter import ContentFilter
            
            self.abuse_detector = AbuseDetector()
            self.escalation_detector = EscalationDetector()
            self.crisis_detector = CrisisDetector()
            self.content_filter = ContentFilter()
            
            # Train abuse detector with sample data if no pre-trained model
            if not self.abuse_detector.load_model('models/abuse_detector.pkl'):
                training_data = self.abuse_detector.get_sample_training_data()
                self.abuse_detector.train_model(training_data)
                
            print("Safety models initialized successfully")
            return True
            
        except Exception as e:
            print(f"Error initializing models: {e}")
            return False
    
    def assess_content_safety(self, text: str, user_age: int = None, 
                            guardian_settings: Dict = None) -> SafetyAssessment:
        """Comprehensive safety assessment of content."""
        timestamp = time.time()
        
        # Individual model assessments
        assessments = {}
        
        # Abuse Detection
        if self.abuse_detector:
            abuse_result = self.abuse_detector.predict(text)
            assessments['abuse'] = {
                'score': abuse_result['confidence'],
                'is_detected': abuse_result['is_abuse'],
                'details': abuse_result
            }
        
        # Escalation Detection
        if self.escalation_detector:
            escalation_result = self.escalation_detector.predict_escalation(text, timestamp)
            assessments['escalation'] = {
                'score': escalation_result['escalation_score'],
                'is_detected': escalation_result['is_escalating'],
                'details': escalation_result
            }
        
        # Crisis Detection
        if self.crisis_detector:
            crisis_result = self.crisis_detector.predict_crisis(text)
            assessments['crisis'] = {
                'score': crisis_result['crisis_score'],
                'is_detected': crisis_result['is_crisis'],
                'details': crisis_result
            }
        
        # Content Filtering (if age provided)
        if self.content_filter and user_age is not None:
            content_result = self.content_filter.filter_content(text, user_age, guardian_settings)
            assessments['content'] = {
                'score': 1.0 - content_result['appropriateness_score'],  # Invert for risk score
                'is_detected': not content_result['is_appropriate'],
                'details': content_result
            }
        
        # Calculate overall safety assessment
        overall_assessment = self._calculate_overall_safety(assessments)
        
        # Store in history
        self.assessment_history.append(overall_assessment)
        
        return overall_assessment
    
    def _calculate_overall_safety(self, assessments: Dict) -> SafetyAssessment:
        """Calculate overall safety level from individual assessments."""
        # Calculate weighted average score
        total_score = 0.0
        total_weight = 0.0
        alerts = []
        recommendations = []
        requires_intervention = False
        
        individual_scores = {}
        
        for model_name, assessment in assessments.items():
            score = assessment['score']
            weight = self.model_weights.get(model_name, 0.25)
            
            individual_scores[model_name] = score
            total_score += score * weight
            total_weight += weight
            
            # Check for alerts
            if assessment['is_detected']:
                model_display = model_name.replace('_', ' ').title()
                alerts.append(f"{model_display} detected")
                
                # Add specific explanations
                if 'explanation' in assessment['details']:
                    for explanation in assessment['details']['explanation']:
                        alerts.append(f"- {explanation}")
                
                # Check for intervention requirements
                if model_name == 'crisis' and assessment['details'].get('intervention_needed'):
                    requires_intervention = True
                    recommendations.extend([
                        "IMMEDIATE INTERVENTION REQUIRED",
                        "Contact mental health professional or emergency services"
                    ])
                
                # Add model-specific recommendations
                if 'recommendations' in assessment['details']:
                    recommendations.extend(assessment['details']['recommendations'])
        
        # Normalize overall score
        overall_score = total_score / total_weight if total_weight > 0 else 0.0
        
        # Determine safety level
        safety_level = self._determine_safety_level(overall_score, individual_scores, requires_intervention)
        
        return SafetyAssessment(
            safety_level=safety_level,
            overall_score=overall_score,
            individual_scores=individual_scores,
            alerts=alerts,
            recommendations=recommendations,
            requires_intervention=requires_intervention,
            timestamp=time.time()
        )
    
    def _determine_safety_level(self, overall_score: float, 
                               individual_scores: Dict[str, float],
                               requires_intervention: bool) -> SafetyLevel:
        """Determine safety level based on scores and flags."""
        
        # Critical level - immediate intervention needed
        if requires_intervention or individual_scores.get('crisis', 0) > 0.9:
            return SafetyLevel.CRITICAL
        
        # Danger level - high risk detected
        if (overall_score > 0.8 or 
            individual_scores.get('crisis', 0) > 0.7 or
            individual_scores.get('abuse', 0) > 0.8):
            return SafetyLevel.DANGER
        
        # Warning level - moderate risk
        if (overall_score > 0.6 or 
            individual_scores.get('escalation', 0) > 0.7 or
            individual_scores.get('abuse', 0) > 0.6):
            return SafetyLevel.WARNING
        
        # Caution level - low risk
        if overall_score > 0.3:
            return SafetyLevel.CAUTION
        
        # Safe level
        return SafetyLevel.SAFE
    
    def get_safety_report(self, include_history: bool = False) -> Dict:
        """Generate comprehensive safety report."""
        if not self.assessment_history:
            return {"error": "No assessments available"}
        
        latest_assessment = self.assessment_history[-1]
        
        report = {
            'current_status': {
                'safety_level': latest_assessment.safety_level.value,
                'overall_score': latest_assessment.overall_score,
                'requires_intervention': latest_assessment.requires_intervention,
                'timestamp': latest_assessment.timestamp
            },
            'model_scores': latest_assessment.individual_scores,
            'alerts': latest_assessment.alerts,
            'recommendations': latest_assessment.recommendations
        }
        
        if include_history:
            report['history'] = {
                'total_assessments': len(self.assessment_history),
                'recent_trends': self._analyze_trends(),
                'risk_patterns': self._identify_risk_patterns()
            }
        
        return report
    
    def _analyze_trends(self) -> Dict:
        """Analyze trends in safety assessments."""
        if len(self.assessment_history) < 2:
            return {"insufficient_data": True}
        
        recent = self.assessment_history[-5:]  # Last 5 assessments
        
        # Calculate trend direction
        scores = [assessment.overall_score for assessment in recent]
        if len(scores) >= 2:
            trend = "increasing" if scores[-1] > scores[0] else "decreasing"
        else:
            trend = "stable"
        
        # Calculate average risk level
        avg_score = sum(scores) / len(scores)
        
        return {
            'trend_direction': trend,
            'average_risk_score': avg_score,
            'assessments_analyzed': len(recent)
        }
    
    def _identify_risk_patterns(self) -> List[str]:
        """Identify recurring risk patterns."""
        patterns = []
        
        if len(self.assessment_history) < 3:
            return patterns
        
        recent = self.assessment_history[-10:]  # Last 10 assessments
        
        # Check for recurring model triggers
        model_triggers = {'abuse': 0, 'escalation': 0, 'crisis': 0, 'content': 0}
        
        for assessment in recent:
            for model, score in assessment.individual_scores.items():
                if score > self.thresholds.get(model, 0.5):
                    model_triggers[model] += 1
        
        # Identify patterns
        total_assessments = len(recent)
        for model, count in model_triggers.items():
            if count > total_assessments * 0.5:  # More than 50% of assessments
                patterns.append(f"Recurring {model} issues detected")
        
        # Check for escalation patterns
        escalation_scores = [a.individual_scores.get('escalation', 0) for a in recent]
        if len(escalation_scores) >= 3:
            increasing_escalation = all(
                escalation_scores[i] <= escalation_scores[i+1] 
                for i in range(len(escalation_scores)-1)
            )
            if increasing_escalation:
                patterns.append("Progressive escalation pattern detected")
        
        return patterns
    
    def reset_session(self):
        """Reset session data (e.g., conversation history)."""
        if self.escalation_detector:
            self.escalation_detector.reset_conversation()
        
        self.assessment_history.clear()
        
    def export_assessment_data(self, filepath: str):
        """Export assessment history to JSON file."""
        try:
            data = []
            for assessment in self.assessment_history:
                data.append({
                    'safety_level': assessment.safety_level.value,
                    'overall_score': assessment.overall_score,
                    'individual_scores': assessment.individual_scores,
                    'alerts': assessment.alerts,
                    'recommendations': assessment.recommendations,
                    'requires_intervention': assessment.requires_intervention,
                    'timestamp': assessment.timestamp
                })
            
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=2)
                
            return True
        except Exception as e:
            print(f"Error exporting data: {e}")
            return False
